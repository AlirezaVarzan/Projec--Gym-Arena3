<?php
/**
 * ═══════════════════════════════════════════════════════════
 *  خروج از حساب کاربری
 * ═══════════════════════════════════════════════════════════
 */
require_once __DIR__ . '/config.php';

// پاک کردن تمام متغیرهای سشن
$_SESSION = [];

/* حذف کوکی سشن از مرورگر کاربر.
   بدون این کار، شناسهٔ سشن در مرورگر باقی می‌ماند.            */
if (ini_get('session.use_cookies')) {
    $params = session_get_cookie_params();
    setcookie(
        session_name(),
        '',
        [
            'expires'  => time() - 42000, // تاریخ انقضا در گذشته → حذف کوکی
            'path'     => $params['path'],
            'domain'   => $params['domain'],
            'secure'   => $params['secure'],
            'httponly' => $params['httponly'],
            'samesite' => $params['samesite'] ?? 'Lax',
        ]
    );
}

// نابود کردن کامل سشن روی سرور
session_destroy();

redirect('index.php');
