<?php
/**
 * ═══════════════════════════════════════════════════════════
 *  صفحهٔ اختصاصی قهرمان
 *  شامل: عکس/آواتار، لقب، بیوگرافی کامل، رشته و کشور،
 *  باشگاه‌های همان رشته برای الگوبرداری عملی، و قهرمانان مشابه.
 * ═══════════════════════════════════════════════════════════
 */
require_once __DIR__ . '/config.php';

$champion_id = (int) ($_GET['id'] ?? 0);

if ($champion_id <= 0) {
    redirect('champions.php');
}

/* ─── دریافت اطلاعات قهرمان ─── */
$stmt = $pdo->prepare("
    SELECT c.*, s.name AS sport_name, s.icon AS sport_icon, s.id AS sport_id
    FROM champions c
    JOIN sports s ON c.sport_id = s.id
    WHERE c.id = ?
    LIMIT 1
");
$stmt->execute([$champion_id]);
$champion = $stmt->fetch();

if (!$champion) {
    http_response_code(404);
    $page_title = 'قهرمان پیدا نشد — آرِنا';
    include __DIR__ . '/header.php';
    echo '<div class="container"><div class="empty-state"><span class="icon">🚫</span><p>چنین قهرمانی پیدا نشد.</p>'
        . '<p class="hint"><a href="champions.php">بازگشت به فهرست قهرمانان</a></p></div></div>';
    include __DIR__ . '/footer.php';
    exit;
}

// قهرمانان دیگر همین رشته (برای الگوبرداری بیشتر)
$peersStmt = $pdo->prepare("
    SELECT id, name, title, country
    FROM champions
    WHERE sport_id = ? AND id <> ?
    ORDER BY RAND()
    LIMIT 4
");
$peersStmt->execute([$champion['sport_id'], $champion_id]);
$peers = $peersStmt->fetchAll();

// باشگاه‌های برتر همین رشته — الهام‌بخش برای شروع تمرین
$clubsStmt = $pdo->prepare("
    SELECT id, name, city, rating
    FROM clubs
    WHERE sport_id = ?
    ORDER BY rating DESC
    LIMIT 4
");
$clubsStmt->execute([$champion['sport_id']]);
$topClubs = $clubsStmt->fetchAll();

$page_title = $champion['name'] . ' — آرِنا';

include __DIR__ . '/header.php';
?>

<div class="container">

    <a href="champions.php" class="back-link">→ بازگشت به فهرست قهرمانان</a>

    <!-- ═══════════ سربرگ قهرمان ═══════════ -->
    <section class="champion-detail-hero">
        <div class="champion-detail-avatar">
            <?php if (!empty($champion['profileimg'])): ?>
                <img src="<?= e($champion['profileimg']) ?>" alt="<?= e($champion['name']) ?>" decoding="async">
            <?php else: ?>
                <span><?= e(initials($champion['name'])) ?></span>
            <?php endif; ?>
        </div>
        <div class="champion-detail-info">
            <h1><?= e($champion['name']) ?></h1>
            <?php if (!empty($champion['title'])): ?>
                <div class="champion-detail-title">🏆 <?= e($champion['title']) ?></div>
            <?php endif; ?>
            <p class="champion-detail-sport">
                <?= e($champion['sport_icon']) ?> <?= e($champion['sport_name']) ?> · 🌍 <?= e($champion['country']) ?>
            </p>
        </div>
    </section>

    <div class="club-detail-grid">

        <!-- ─── ستون اصلی: بیوگرافی ─── -->
        <div class="club-detail-main">
            <?php if (!empty($champion['bio'])): ?>
                <section class="section-compact">
                    <h2 class="subsection-title">دربارهٔ قهرمان</h2>
                    <p class="club-description"><?= e($champion['bio']) ?></p>
                </section>
            <?php endif; ?>

            <?php if ($topClubs): ?>
                <section class="section-compact">
                    <h2 class="subsection-title">می‌خوای مثل او تمرین کنی؟</h2>
                    <p class="hint" style="margin-bottom:16px;">بهترین باشگاه‌های <?= e($champion['sport_name']) ?> را ببین:</p>
                    <div class="clubs-grid">
                        <?php foreach ($topClubs as $c): ?>
                            <a class="similar-club" href="club.php?id=<?= e($c['id']) ?>">
                                <span><?= e($c['name']) ?></span>
                                <span class="similar-club-meta">📍 <?= e($c['city']) ?> · ⭐ <?= toPersianDigits(number_format((float) $c['rating'], 1)) ?></span>
                            </a>
                        <?php endforeach; ?>
                    </div>
                </section>
            <?php endif; ?>
        </div>

        <!-- ─── ستون کناری: قهرمانان مشابه ─── -->
        <aside class="club-detail-side">
            <h2 class="subsection-title">مشخصات</h2>
            <ul class="club-facts">
                <li><span class="fact-ico"><?= e($champion['sport_icon']) ?></span><div><strong>رشتهٔ ورزشی</strong><br><?= e($champion['sport_name']) ?></div></li>
                <li><span class="fact-ico">🌍</span><div><strong>کشور</strong><br><?= e($champion['country']) ?></div></li>
                <?php if (!empty($champion['title'])): ?>
                    <li><span class="fact-ico">🏆</span><div><strong>افتخار</strong><br><?= e($champion['title']) ?></div></li>
                <?php endif; ?>
            </ul>

            <?php if ($peers): ?>
                <h2 class="subsection-title" style="margin-top:32px;">دیگر قهرمانان <?= e($champion['sport_name']) ?></h2>
                <div class="similar-clubs">
                    <?php foreach ($peers as $p): ?>
                        <a class="similar-club" href="champion.php?id=<?= e($p['id']) ?>">
                            <span><?= e($p['name']) ?></span>
                            <span class="similar-club-meta"><?= e($p['title'] ?? $p['country']) ?></span>
                        </a>
                    <?php endforeach; ?>
                </div>
            <?php endif; ?>
        </aside>
    </div>
</div>

<?php include __DIR__ . '/footer.php'; ?>
