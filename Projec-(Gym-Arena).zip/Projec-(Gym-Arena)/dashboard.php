<?php
/**
 * ═══════════════════════════════════════════════════════════
 *  داشبورد ورزشکار
 *  نمایش قهرمانان رشتهٔ کاربر + باشگاه‌های شهر او
 * ═══════════════════════════════════════════════════════════
 */
require_once __DIR__ . '/config.php';
requireLogin();

/* ═══════════════════════════════════════════════════════════
   بخش ۱ — پردازش فرم «تغییر رشته / شهر»
   ───────────────────────────────────────────────────────────
   این بخش باید *قبل از* خواندن اطلاعات کاربر اجرا شود تا پس
   از به‌روزرسانی، داده‌های تازه نمایش داده شوند.
   ═══════════════════════════════════════════════════════════ */
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['update_preferences'])) {

    verifyCsrf();

    $new_sport = (int) ($_POST['favorite_sport'] ?? 0);
    $new_city  = trim($_POST['city'] ?? '');

    if ($new_sport > 0 && mb_strlen($new_city) >= 2) {
        $pdo->prepare("UPDATE users SET favorite_sport = ?, city = ? WHERE id = ?")
            ->execute([$new_sport, $new_city, $_SESSION['user_id']]);

        flash('success', 'اطلاعات شما با موفقیت به‌روزرسانی شد.');
    } else {
        flash('error', 'لطفاً رشته و شهر معتبر انتخاب کنید.');
    }

    // الگوی POST/Redirect/GET → جلوگیری از ارسال دوبارهٔ فرم با رفرش صفحه
    redirect('dashboard.php');
}

/* ═══════════════════════════════════════════════════════════
   بخش ۲ — دریافت اطلاعات کاربر
   ═══════════════════════════════════════════════════════════ */
$stmt = $pdo->prepare("
    SELECT u.id, u.full_name, u.age, u.city, u.favorite_sport,
           s.name AS sport_name, s.icon AS sport_icon
    FROM users u
    LEFT JOIN sports s ON u.favorite_sport = s.id
    WHERE u.id = ?
    LIMIT 1
");
$stmt->execute([$_SESSION['user_id']]);
$user = $stmt->fetch();

// اگر کاربر در دیتابیس نبود (مثلاً حذف شده)، سشن را پاک کن
if (!$user) {
    session_unset();
    session_destroy();
    redirect('index.php');
}

/* ═══════════════════════════════════════════════════════════
   بخش ۳ — داده‌های نمایشی
   ═══════════════════════════════════════════════════════════ */
$sports = $pdo->query("SELECT id, name, icon FROM sports ORDER BY id ASC")->fetchAll();

// قهرمانان رشتهٔ انتخابی کاربر
$champions = [];
if ($user['favorite_sport']) {
    $cs = $pdo->prepare("
        SELECT name, title, bio, country, profileimg
        FROM champions
        WHERE sport_id = ?
        ORDER BY id ASC
    ");
    $cs->execute([$user['favorite_sport']]);
    $champions = $cs->fetchAll();
}

$clubs_in_city      = [];
$clubs_other_cities = [];

if ($user['favorite_sport'] && $user['city']) {

    // باشگاه‌های همان رشته در شهر کاربر
    $cl = $pdo->prepare("
        SELECT c.name, c.city, c.address, c.phone, s.icon AS sport_icon
        FROM clubs c
        JOIN sports s ON c.sport_id = s.id
        WHERE c.sport_id = ? AND c.city = ?
        ORDER BY c.id ASC
    ");
    $cl->execute([$user['favorite_sport'], $user['city']]);
    $clubs_in_city = $cl->fetchAll();

    // باشگاه‌های همان رشته در سایر شهرها (به‌عنوان پیشنهاد)
    $cl2 = $pdo->prepare("
        SELECT c.name, c.city, c.phone, s.icon AS sport_icon
        FROM clubs c
        JOIN sports s ON c.sport_id = s.id
        WHERE c.sport_id = ? AND c.city <> ?
        ORDER BY c.id ASC
        LIMIT 6
    ");
    $cl2->execute([$user['favorite_sport'], $user['city']]);
    $clubs_other_cities = $cl2->fetchAll();
}

// فهرست شهرهایی که واقعاً باشگاه دارند → برای راهنمایی کاربر (datalist)
$known_cities = $pdo->query("SELECT DISTINCT city FROM clubs ORDER BY city ASC")->fetchAll(PDO::FETCH_COLUMN);

// باشگاه‌های علاقه‌مندی کاربر (ویژگی جدید)
$favStmt = $pdo->prepare("
    SELECT c.id, c.name, c.city, c.rating, s.icon AS sport_icon, s.name AS sport_name
    FROM favorites f
    JOIN clubs c ON f.club_id = c.id
    JOIN sports s ON c.sport_id = s.id
    WHERE f.user_id = ?
    ORDER BY f.created_at DESC
");
$favStmt->execute([$_SESSION['user_id']]);
$favorite_clubs = $favStmt->fetchAll();

$success = flash('success');
$error   = flash('error');

$page_title = 'داشبورد — ' . $user['full_name'];

include __DIR__ . '/header.php';
?>

<!-- ═══════════ سربرگ داشبورد ═══════════ -->
<section class="dashboard-hero">
    <div class="container">
        <div class="dashboard-greeting">سلام،</div>
        <h1 class="dashboard-name"><?= e($user['full_name']) ?> 👋</h1>
        <p class="dashboard-lead">
            خوش آمدی به آرِنا! اینجا قهرمانان رشتهٔ محبوبت و باشگاه‌های شهرت را می‌بینی.
        </p>

        <div class="dashboard-meta">
            <span class="meta-chip">
                <svg class="ico" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" aria-hidden="true">
                    <circle cx="12" cy="12" r="10"/><path d="M12 6v6l4 2"/>
                </svg>
                <strong>سن:</strong> <?= toPersianDigits((int) $user['age']) ?> سال
            </span>
            <span class="meta-chip">
                <svg class="ico" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" aria-hidden="true">
                    <path d="M21 10c0 7-9 13-9 13s-9-6-9-13a9 9 0 0 1 18 0z"/><circle cx="12" cy="10" r="3"/>
                </svg>
                <strong>شهر:</strong> <?= e($user['city']) ?>
            </span>
            <span class="meta-chip">
                <span class="ico-emoji" aria-hidden="true"><?= e($user['sport_icon'] ?? '🏆') ?></span>
                <strong>رشته:</strong> <?= e($user['sport_name'] ?? 'انتخاب نشده') ?>
            </span>
        </div>
    </div>
</section>

<div class="container">

    <!-- پیام‌های وضعیت -->
    <?php if ($success): ?>
        <div class="form-message success" role="status">
            <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" aria-hidden="true">
                <path d="M20 6 9 17l-5-5"/>
            </svg>
            <span><?= e($success) ?></span>
        </div>
    <?php endif; ?>

    <?php if ($error): ?>
        <div class="form-message error" role="alert">
            <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" aria-hidden="true">
                <circle cx="12" cy="12" r="10"/><path d="M12 8v4M12 16h.01"/>
            </svg>
            <span><?= e($error) ?></span>
        </div>
    <?php endif; ?>

    <!-- ═══════════ فرم تغییر رشته و شهر ═══════════ -->
    <form method="POST" class="sport-selector">
        <?= csrfField() ?>

        <div class="selector-field">
            <label for="sel_sport">رشتهٔ ورزشی</label>
            <select id="sel_sport" name="favorite_sport" class="form-control" required>
                <?php foreach ($sports as $sp): ?>
                    <option value="<?= e($sp['id']) ?>"
                        <?= $sp['id'] == $user['favorite_sport'] ? 'selected' : '' ?>>
                        <?= e($sp['icon']) ?> <?= e($sp['name']) ?>
                    </option>
                <?php endforeach; ?>
            </select>
        </div>

        <div class="selector-field">
            <label for="sel_city">شهر</label>
            <!-- datalist → پیشنهاد خودکار شهرهایی که باشگاه دارند -->
            <input type="text" id="sel_city" name="city" class="form-control"
                   list="cityList" value="<?= e($user['city']) ?>"
                   placeholder="نام شهر" required>
            <datalist id="cityList">
                <?php foreach ($known_cities as $c): ?>
                    <option value="<?= e($c) ?>"></option>
                <?php endforeach; ?>
            </datalist>
        </div>

        <button type="submit" name="update_preferences" value="1" class="btn btn-primary">
            به‌روزرسانی
        </button>
    </form>

    <!-- ═══════════ قهرمانان رشتهٔ کاربر ═══════════ -->
    <section class="section section-compact">
        <div class="section-header section-header-start">
            <div class="section-eyebrow">قهرمانان</div>
            <h2 class="section-title">
                <?= e($user['sport_icon'] ?? '🏆') ?>
                بزرگان <?= e($user['sport_name'] ?? '') ?>
            </h2>
            <p class="section-subtitle">
                این قهرمانان نام خود را در تاریخ این رشته ثبت کرده‌اند. الگو بگیر و بزرگ شو.
            </p>
        </div>

        <?php if (!$champions): ?>
            <div class="empty-state">
                <span class="icon" aria-hidden="true">🏅</span>
                <p>هنوز قهرمانی برای این رشته ثبت نشده است.</p>
            </div>
        <?php else: ?>
            <div class="champions-grid reveal-group">
                <?php foreach ($champions as $champ): ?>
                    <article class="champion-card">
                        <div class="champion-avatar">
                            <?php if (!empty($champ['profileimg'])): ?>
                                <img src="<?= e($champ['profileimg']) ?>"
                                     alt="<?= e($champ['name']) ?>"
                                     loading="lazy" decoding="async">
                            <?php else: ?>
                                <!-- نبودِ عکس → نمایش حرف اول نام به‌جای کادر خالی -->
                                <span><?= e(initials($champ['name'])) ?></span>
                            <?php endif; ?>
                        </div>

                        <h3 class="champion-name"><?= e($champ['name']) ?></h3>

                        <?php if (!empty($champ['title'])): ?>
                            <div class="champion-title"><?= e($champ['title']) ?></div>
                        <?php endif; ?>

                        <?php if (!empty($champ['bio'])): ?>
                            <p class="champion-bio"><?= e($champ['bio']) ?></p>
                        <?php endif; ?>

                        <span class="champion-country">🌍 <?= e($champ['country']) ?></span>
                    </article>
                <?php endforeach; ?>
            </div>
        <?php endif; ?>
    </section>

    <!-- ═══════════ باشگاه‌های شهر کاربر ═══════════ -->
    <section class="section section-compact" id="clubs">
        <div class="section-header section-header-start">
            <div class="section-eyebrow">باشگاه‌ها</div>
            <h2 class="section-title">
                <?= e($user['sport_name'] ?? '') ?> در <?= e($user['city']) ?>
            </h2>
            <p class="section-subtitle">
                باشگاه‌های فعال رشتهٔ تو در شهر <?= e($user['city']) ?> —
                <a href="clubs.php">یا در همهٔ باشگاه‌ها جست‌وجو کن</a>
            </p>
        </div>

        <?php if (!$clubs_in_city): ?>
            <div class="empty-state">
                <span class="icon" aria-hidden="true">🏟️</span>
                <p>
                    باشگاهی برای رشتهٔ <?= e($user['sport_name'] ?? '') ?>
                    در شهر <?= e($user['city']) ?> ثبت نشده است.
                </p>
                <p class="hint">می‌توانی شهر دیگری را امتحان کنی یا پیشنهادهای پایین را ببینی.</p>
            </div>
        <?php else: ?>
            <div class="clubs-grid reveal-group">
                <?php foreach ($clubs_in_city as $club): ?>
                    <article class="club-card">
                        <div class="club-icon" aria-hidden="true"><?= e($club['sport_icon']) ?></div>
                        <div class="club-content">
                            <h3 class="club-name"><?= e($club['name']) ?></h3>
                            <div class="club-meta">
                                <span>📍 <strong><?= e($club['city']) ?></strong></span>
                                <?php if (!empty($club['address'])): ?>
                                    <span><?= e($club['address']) ?></span>
                                <?php endif; ?>
                                <?php if (!empty($club['phone'])): ?>
                                    <span>☎ <?= e($club['phone']) ?></span>
                                <?php endif; ?>
                            </div>
                        </div>
                    </article>
                <?php endforeach; ?>
            </div>
        <?php endif; ?>

        <!-- پیشنهاد: باشگاه‌های همین رشته در شهرهای دیگر -->
        <?php if ($clubs_other_cities): ?>
            <div class="clubs-suggested">
                <h3 class="subsection-title">
                    باشگاه‌های <?= e($user['sport_name'] ?? '') ?> در سایر شهرها
                </h3>
                <div class="clubs-grid">
                    <?php foreach ($clubs_other_cities as $club): ?>
                        <article class="club-card is-muted">
                            <div class="club-icon" aria-hidden="true"><?= e($club['sport_icon']) ?></div>
                            <div class="club-content">
                                <h3 class="club-name"><?= e($club['name']) ?></h3>
                                <div class="club-meta">
                                    <span>📍 <strong><?= e($club['city']) ?></strong></span>
                                    <?php if (!empty($club['phone'])): ?>
                                        <span>☎ <?= e($club['phone']) ?></span>
                                    <?php endif; ?>
                                </div>
                            </div>
                        </article>
                    <?php endforeach; ?>
                </div>
            </div>
        <?php endif; ?>
    </section>

    <!-- ═══════════ علاقه‌مندی‌های من ═══════════ -->
    <?php if ($favorite_clubs): ?>
        <section class="section section-compact" id="favorites">
            <div class="section-header section-header-start">
                <div class="section-eyebrow">علاقه‌مندی‌ها</div>
                <h2 class="section-title">❤ باشگاه‌های ذخیره‌شدهٔ من</h2>
                <p class="section-subtitle">باشگاه‌هایی که برای بعداً نشان کرده‌ای.</p>
            </div>

            <div class="clubs-grid reveal-group">
                <?php foreach ($favorite_clubs as $fc): ?>
                    <a class="club-card club-card-link" href="club.php?id=<?= e($fc['id']) ?>">
                        <div class="club-icon" aria-hidden="true"><?= e($fc['sport_icon']) ?></div>
                        <div class="club-content">
                            <h3 class="club-name"><?= e($fc['name']) ?></h3>
                            <div class="club-meta">
                                <span>📍 <strong><?= e($fc['city']) ?></strong> · <?= e($fc['sport_name']) ?></span>
                                <span>⭐ <?= toPersianDigits(number_format((float) $fc['rating'], 1)) ?></span>
                            </div>
                        </div>
                    </a>
                <?php endforeach; ?>
            </div>
        </section>
    <?php endif; ?>

</div>

<?php include __DIR__ . '/footer.php'; ?>
