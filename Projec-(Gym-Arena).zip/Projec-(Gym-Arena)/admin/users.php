<?php
/**
 * ═══════════════════════════════════════════════════════════
 *  پنل مدیریت — مدیریت کاربران
 *  اعطا/سلب دسترسی ادمین و حذف کاربران.
 * ═══════════════════════════════════════════════════════════
 */
require_once __DIR__ . '/../config.php';
requireAdmin();

$currentUserId = (int) $_SESSION['user_id'];

/* ═══════════════════════════════════════════════════════════
   تغییر سطح دسترسی ادمین
   ═══════════════════════════════════════════════════════════ */
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['toggle_admin'])) {
    verifyCsrf();
    $id = (int) ($_POST['id'] ?? 0);

    if ($id === $currentUserId) {
        flash('error', 'نمی‌توانی سطح دسترسی خودت را تغییر دهی.');
    } else {
        $pdo->prepare("UPDATE users SET is_admin = NOT is_admin WHERE id = ?")->execute([$id]);
        flash('success', 'سطح دسترسی کاربر با موفقیت تغییر کرد.');
    }
    redirect('users.php');
}

/* ═══════════════════════════════════════════════════════════
   حذف کاربر
   ═══════════════════════════════════════════════════════════ */
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['delete_user'])) {
    verifyCsrf();
    $id = (int) ($_POST['id'] ?? 0);

    if ($id === $currentUserId) {
        flash('error', 'نمی‌توانی حساب خودت را حذف کنی.');
    } else {
        $pdo->prepare("DELETE FROM users WHERE id = ?")->execute([$id]);
        flash('success', 'کاربر با موفقیت حذف شد.');
    }
    redirect('users.php');
}

/* ═══════════════════════════════════════════════════════════
   فهرست کاربران (با جست‌وجوی نام/نام‌کاربری)
   ═══════════════════════════════════════════════════════════ */
$q = trim((string) ($_GET['q'] ?? ''));

$sql = "
    SELECT u.id, u.full_name, u.username, u.city, u.age, u.is_admin, u.created_at,
           s.name AS sport_name, s.icon AS sport_icon
    FROM users u
    LEFT JOIN sports s ON u.favorite_sport = s.id
";
$params = [];
if ($q !== '') {
    $sql .= " WHERE u.full_name LIKE ? OR u.username LIKE ?";
    $params = ["%{$q}%", "%{$q}%"];
}
$sql .= " ORDER BY u.created_at DESC";

$stmt = $pdo->prepare($sql);
$stmt->execute($params);
$users = $stmt->fetchAll();

$success = flash('success');
$error   = flash('error');

$page_title = 'مدیریت کاربران — پنل مدیریت';
include __DIR__ . '/_header.php';
?>

<div class="admin-topbar">
    <div>
        <h1>مدیریت کاربران</h1>
        <p><?= toPersianDigits(count($users)) ?> کاربر ثبت‌نام کرده است.</p>
    </div>
</div>

<?php if ($success): ?>
    <div class="form-message success" role="status"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" aria-hidden="true"><path d="M20 6 9 17l-5-5"/></svg><span><?= e($success) ?></span></div>
<?php endif; ?>
<?php if ($error): ?>
    <div class="form-message error" role="alert"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" aria-hidden="true"><circle cx="12" cy="12" r="10"/><path d="M12 8v4M12 16h.01"/></svg><span><?= e($error) ?></span></div>
<?php endif; ?>

<section class="admin-panel-card">
    <form method="GET" class="admin-search-bar">
        <input type="text" name="q" class="form-control" placeholder="جست‌وجوی نام یا نام کاربری…" value="<?= e($q) ?>">
        <button type="submit" class="btn btn-primary btn-sm">جست‌وجو</button>
        <?php if ($q !== ''): ?>
            <a href="users.php" class="btn btn-ghost btn-sm">پاک کردن</a>
        <?php endif; ?>
    </form>

    <?php if (!$users): ?>
        <p class="hint">کاربری پیدا نشد.</p>
    <?php else: ?>
        <div class="admin-table-wrap">
            <table class="admin-table">
                <thead>
                    <tr><th>نام</th><th>شهر</th><th>رشته</th><th>سطح دسترسی</th><th>عضویت</th><th></th></tr>
                </thead>
                <tbody>
                    <?php foreach ($users as $u): ?>
                        <tr>
                            <td><?= e($u['full_name']) ?><br><span class="admin-td-sub">@<?= e($u['username']) ?></span></td>
                            <td><?= e($u['city']) ?></td>
                            <td><?= e($u['sport_icon'] ?? '—') ?> <?= e($u['sport_name'] ?? '') ?></td>
                            <td>
                                <?php if ($u['is_admin']): ?>
                                    <span class="admin-badge admin-badge-accent">ادمین</span>
                                <?php else: ?>
                                    <span class="admin-badge">کاربر عادی</span>
                                <?php endif; ?>
                            </td>
                            <td><?= e(toPersianDigits(date('Y/m/d', strtotime($u['created_at'])))) ?></td>
                            <td class="admin-table-actions">
                                <?php if ((int) $u['id'] !== $currentUserId): ?>
                                    <form method="POST">
                                        <?= csrfField() ?>
                                        <input type="hidden" name="id" value="<?= e($u['id']) ?>">
                                        <button type="submit" name="toggle_admin" value="1" class="btn btn-ghost btn-sm">
                                            <?= $u['is_admin'] ? 'سلب دسترسی' : 'ادمین کن' ?>
                                        </button>
                                    </form>
                                    <form method="POST" data-confirm="آیا از حذف «<?= e($u['full_name']) ?>» مطمئن هستی؟">
                                        <?= csrfField() ?>
                                        <input type="hidden" name="id" value="<?= e($u['id']) ?>">
                                        <button type="submit" name="delete_user" value="1" class="btn btn-danger btn-sm">حذف</button>
                                    </form>
                                <?php else: ?>
                                    <span class="admin-td-sub">(حساب شما)</span>
                                <?php endif; ?>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        </div>
    <?php endif; ?>
</section>

<?php include __DIR__ . '/_footer.php'; ?>
