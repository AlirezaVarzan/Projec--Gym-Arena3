<?php
/**
 * ═══════════════════════════════════════════════════════════
 *  پنل مدیریت — مدیریت باشگاه‌ها
 *  افزودن، ویرایش و حذف باشگاه‌ها.
 * ═══════════════════════════════════════════════════════════
 */
require_once __DIR__ . '/../config.php';
requireAdmin();

$sports = $pdo->query("SELECT id, name, icon FROM sports ORDER BY id ASC")->fetchAll();

/* ═══════════════════════════════════════════════════════════
   حذف باشگاه
   ═══════════════════════════════════════════════════════════ */
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['delete_club'])) {
    verifyCsrf();
    $id = (int) ($_POST['id'] ?? 0);
    $pdo->prepare("DELETE FROM clubs WHERE id = ?")->execute([$id]);
    flash('success', 'باشگاه با موفقیت حذف شد.');
    redirect('clubs.php');
}

/* ═══════════════════════════════════════════════════════════
   افزودن یا ویرایش باشگاه
   ═══════════════════════════════════════════════════════════ */
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['save_club'])) {
    verifyCsrf();

    $id               = (int) ($_POST['id'] ?? 0);
    $name             = trim($_POST['name'] ?? '');
    $sport_id         = (int) ($_POST['sport_id'] ?? 0);
    $city             = trim($_POST['city'] ?? '');
    $address          = trim($_POST['address'] ?? '');
    $phone            = trim($_POST['phone'] ?? '');
    $description      = trim($_POST['description'] ?? '');
    $price_monthly    = (int) toEnglishDigits((string) ($_POST['price_monthly'] ?? '0'));
    $working_hours    = trim($_POST['working_hours'] ?? '');
    $capacity         = (int) toEnglishDigits((string) ($_POST['capacity'] ?? '0'));
    $established_year = (int) toEnglishDigits((string) ($_POST['established_year'] ?? '0'));
    $instagram        = trim($_POST['instagram'] ?? '');
    $rating           = (float) ($_POST['rating'] ?? 4.0);

    $errors = [];
    if (mb_strlen($name) < 3)  $errors[] = 'نام باشگاه باید حداقل ۳ کاراکتر باشد.';
    if ($sport_id <= 0)        $errors[] = 'رشتهٔ ورزشی را انتخاب کن.';
    if (mb_strlen($city) < 2)  $errors[] = 'نام شهر معتبر وارد کن.';
    if ($rating < 0 || $rating > 5) $errors[] = 'امتیاز باید بین ۰ تا ۵ باشد.';

    if ($errors) {
        flash('error', implode(' ', $errors));
        redirect($id ? "clubs.php?edit={$id}" : 'clubs.php?new=1');
    }

    $params = [
        $name, $sport_id, $city, $address ?: null, $phone ?: null, $description ?: null,
        round($rating, 1), $price_monthly ?: null, $working_hours ?: null,
        $capacity ?: null, $established_year ?: null, $instagram ?: null,
    ];

    if ($id > 0) {
        $pdo->prepare("
            UPDATE clubs SET name=?, sport_id=?, city=?, address=?, phone=?, description=?,
                             rating=?, price_monthly=?, working_hours=?, capacity=?, established_year=?, instagram=?
            WHERE id = ?
        ")->execute([...$params, $id]);
        flash('success', 'باشگاه با موفقیت ویرایش شد.');
    } else {
        $pdo->prepare("
            INSERT INTO clubs (name, sport_id, city, address, phone, description, rating, price_monthly, working_hours, capacity, established_year, instagram)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
        ")->execute($params);
        flash('success', 'باشگاه جدید با موفقیت اضافه شد.');
    }

    redirect('clubs.php');
}

/* ═══════════════════════════════════════════════════════════
   داده‌های فرم (در حالت ویرایش) و فهرست باشگاه‌ها
   ═══════════════════════════════════════════════════════════ */
$editing   = null;
$editId    = (int) ($_GET['edit'] ?? 0);
$showForm  = isset($_GET['new']) || $editId > 0;

if ($editId > 0) {
    $es = $pdo->prepare("SELECT * FROM clubs WHERE id = ?");
    $es->execute([$editId]);
    $editing = $es->fetch();
    if (!$editing) {
        redirect('clubs.php');
    }
}

$clubs = $pdo->query("
    SELECT c.id, c.name, c.city, c.rating, c.price_monthly, s.name AS sport_name, s.icon AS sport_icon
    FROM clubs c JOIN sports s ON c.sport_id = s.id
    ORDER BY c.id DESC
")->fetchAll();

$success = flash('success');
$error   = flash('error');

$page_title = 'مدیریت باشگاه‌ها — پنل مدیریت';
include __DIR__ . '/_header.php';
?>

<div class="admin-topbar">
    <div>
        <h1>مدیریت باشگاه‌ها</h1>
        <p><?= toPersianDigits(count($clubs)) ?> باشگاه در حال حاضر ثبت شده است.</p>
    </div>
    <?php if (!$showForm): ?>
        <a href="clubs.php?new=1" class="btn btn-primary">+ افزودن باشگاه جدید</a>
    <?php else: ?>
        <a href="clubs.php" class="btn btn-ghost">بازگشت به فهرست</a>
    <?php endif; ?>
</div>

<?php if ($success): ?>
    <div class="form-message success" role="status"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" aria-hidden="true"><path d="M20 6 9 17l-5-5"/></svg><span><?= e($success) ?></span></div>
<?php endif; ?>
<?php if ($error): ?>
    <div class="form-message error" role="alert"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" aria-hidden="true"><circle cx="12" cy="12" r="10"/><path d="M12 8v4M12 16h.01"/></svg><span><?= e($error) ?></span></div>
<?php endif; ?>

<?php if ($showForm): ?>
    <!-- ═══════════ فرم افزودن/ویرایش ═══════════ -->
    <section class="admin-panel-card">
        <div class="admin-panel-head">
            <h2><?= $editing ? 'ویرایش باشگاه' : 'افزودن باشگاه جدید' ?></h2>
        </div>
        <form method="POST">
            <?= csrfField() ?>
            <input type="hidden" name="id" value="<?= e($editing['id'] ?? 0) ?>">

            <div class="form-row">
                <div class="form-group">
                    <label class="form-label" for="c_name">نام باشگاه</label>
                    <input type="text" id="c_name" name="name" class="form-control" required
                           value="<?= e($editing['name'] ?? '') ?>">
                </div>
                <div class="form-group">
                    <label class="form-label" for="c_sport">رشتهٔ ورزشی</label>
                    <select id="c_sport" name="sport_id" class="form-control" required>
                        <option value="">انتخاب کن…</option>
                        <?php foreach ($sports as $sp): ?>
                            <option value="<?= e($sp['id']) ?>" <?= ($editing['sport_id'] ?? 0) == $sp['id'] ? 'selected' : '' ?>>
                                <?= e($sp['icon']) ?> <?= e($sp['name']) ?>
                            </option>
                        <?php endforeach; ?>
                    </select>
                </div>
            </div>

            <div class="form-row">
                <div class="form-group">
                    <label class="form-label" for="c_city">شهر</label>
                    <input type="text" id="c_city" name="city" class="form-control" required
                           value="<?= e($editing['city'] ?? '') ?>">
                </div>
                <div class="form-group">
                    <label class="form-label" for="c_address">آدرس</label>
                    <input type="text" id="c_address" name="address" class="form-control"
                           value="<?= e($editing['address'] ?? '') ?>">
                </div>
            </div>

            <div class="form-row">
                <div class="form-group">
                    <label class="form-label" for="c_phone">تلفن تماس</label>
                    <input type="text" id="c_phone" name="phone" class="form-control"
                           value="<?= e($editing['phone'] ?? '') ?>">
                </div>
                <div class="form-group">
                    <label class="form-label" for="c_instagram">اینستاگرام</label>
                    <input type="text" id="c_instagram" name="instagram" class="form-control"
                           placeholder="@username" value="<?= e($editing['instagram'] ?? '') ?>">
                </div>
            </div>

            <div class="form-row">
                <div class="form-group">
                    <label class="form-label" for="c_price">هزینهٔ ماهانه (تومان)</label>
                    <input type="text" id="c_price" name="price_monthly" class="form-control" inputmode="numeric"
                           value="<?= e($editing['price_monthly'] ?? '') ?>">
                </div>
                <div class="form-group">
                    <label class="form-label" for="c_hours">ساعات کاری</label>
                    <input type="text" id="c_hours" name="working_hours" class="form-control"
                           placeholder="مثلاً ۷:۰۰ - ۲۲:۰۰" value="<?= e($editing['working_hours'] ?? '') ?>">
                </div>
            </div>

            <div class="form-row">
                <div class="form-group">
                    <label class="form-label" for="c_capacity">ظرفیت (نفر)</label>
                    <input type="text" id="c_capacity" name="capacity" class="form-control" inputmode="numeric"
                           value="<?= e($editing['capacity'] ?? '') ?>">
                </div>
                <div class="form-group">
                    <label class="form-label" for="c_year">سال تأسیس</label>
                    <input type="text" id="c_year" name="established_year" class="form-control" inputmode="numeric"
                           value="<?= e($editing['established_year'] ?? '') ?>">
                </div>
            </div>

            <div class="form-group">
                <label class="form-label" for="c_rating">امتیاز اولیه (۰ تا ۵)</label>
                <input type="number" id="c_rating" name="rating" class="form-control" step="0.1" min="0" max="5"
                       value="<?= e($editing['rating'] ?? '4.0') ?>">
                <small class="hint">توجه: پس از ثبت نظر توسط کاربران، این امتیاز به‌صورت خودکار میانگین‌گیری می‌شود.</small>
            </div>

            <div class="form-group">
                <label class="form-label" for="c_desc">توضیحات</label>
                <textarea id="c_desc" name="description" class="form-control" rows="3"><?= e($editing['description'] ?? '') ?></textarea>
            </div>

            <button type="submit" name="save_club" value="1" class="btn btn-primary">
                <?= $editing ? 'ذخیرهٔ تغییرات' : 'افزودن باشگاه' ?>
            </button>
        </form>
    </section>
<?php else: ?>
    <!-- ═══════════ فهرست باشگاه‌ها ═══════════ -->
    <section class="admin-panel-card">
        <div class="admin-table-wrap">
            <table class="admin-table">
                <thead>
                    <tr><th>نام</th><th>رشته</th><th>شهر</th><th>امتیاز</th><th>هزینه ماهانه</th><th></th></tr>
                </thead>
                <tbody>
                    <?php foreach ($clubs as $c): ?>
                        <tr>
                            <td><a href="../club.php?id=<?= e($c['id']) ?>" target="_blank"><?= e($c['name']) ?></a></td>
                            <td><?= e($c['sport_icon']) ?> <?= e($c['sport_name']) ?></td>
                            <td><?= e($c['city']) ?></td>
                            <td>⭐ <?= toPersianDigits(number_format((float) $c['rating'], 1)) ?></td>
                            <td><?= $c['price_monthly'] ? toPersianDigits(number_format((int) $c['price_monthly'])) . ' تومان' : '—' ?></td>
                            <td class="admin-table-actions">
                                <a href="clubs.php?edit=<?= e($c['id']) ?>" class="btn btn-ghost btn-sm">ویرایش</a>
                                <form method="POST" data-confirm="آیا از حذف «<?= e($c['name']) ?>» مطمئن هستی؟">
                                    <?= csrfField() ?>
                                    <input type="hidden" name="id" value="<?= e($c['id']) ?>">
                                    <button type="submit" name="delete_club" value="1" class="btn btn-danger btn-sm">حذف</button>
                                </form>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        </div>
    </section>
<?php endif; ?>

<?php include __DIR__ . '/_footer.php'; ?>
