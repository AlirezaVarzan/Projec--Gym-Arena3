<?php
/**
 * ═══════════════════════════════════════════════════════════
 *  پنل مدیریت — مدیریت قهرمانان
 *  افزودن، ویرایش و حذف قهرمانان.
 * ═══════════════════════════════════════════════════════════
 */
require_once __DIR__ . '/../config.php';
requireAdmin();

$sports = $pdo->query("SELECT id, name, icon FROM sports ORDER BY id ASC")->fetchAll();

/* ═══════════════════════════════════════════════════════════
   حذف قهرمان
   ═══════════════════════════════════════════════════════════ */
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['delete_champion'])) {
    verifyCsrf();
    $id = (int) ($_POST['id'] ?? 0);
    $pdo->prepare("DELETE FROM champions WHERE id = ?")->execute([$id]);
    flash('success', 'قهرمان با موفقیت حذف شد.');
    redirect('champions.php');
}

/* ═══════════════════════════════════════════════════════════
   افزودن یا ویرایش قهرمان
   ═══════════════════════════════════════════════════════════ */
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['save_champion'])) {
    verifyCsrf();

    $id         = (int) ($_POST['id'] ?? 0);
    $name       = trim($_POST['name'] ?? '');
    $sport_id   = (int) ($_POST['sport_id'] ?? 0);
    $country    = trim($_POST['country'] ?? 'ایران');
    $title      = trim($_POST['title'] ?? '');
    $bio        = trim($_POST['bio'] ?? '');
    $profileimg = trim($_POST['profileimg'] ?? '');

    $errors = [];
    if (mb_strlen($name) < 3) $errors[] = 'نام قهرمان باید حداقل ۳ کاراکتر باشد.';
    if ($sport_id <= 0)       $errors[] = 'رشتهٔ ورزشی را انتخاب کن.';
    if (mb_strlen($country) < 2) $errors[] = 'نام کشور معتبر وارد کن.';

    if ($errors) {
        flash('error', implode(' ', $errors));
        redirect($id ? "champions.php?edit={$id}" : 'champions.php?new=1');
    }

    $params = [$name, $sport_id, $country, $title ?: null, $bio ?: null, $profileimg ?: null];

    if ($id > 0) {
        $pdo->prepare("
            UPDATE champions SET name=?, sport_id=?, country=?, title=?, bio=?, profileimg=?
            WHERE id = ?
        ")->execute([...$params, $id]);
        flash('success', 'اطلاعات قهرمان با موفقیت ویرایش شد.');
    } else {
        $pdo->prepare("
            INSERT INTO champions (name, sport_id, country, title, bio, profileimg)
            VALUES (?, ?, ?, ?, ?, ?)
        ")->execute($params);
        flash('success', 'قهرمان جدید با موفقیت اضافه شد.');
    }

    redirect('champions.php');
}

/* ═══════════════════════════════════════════════════════════
   داده‌های فرم (در حالت ویرایش) و فهرست قهرمانان
   ═══════════════════════════════════════════════════════════ */
$editing  = null;
$editId   = (int) ($_GET['edit'] ?? 0);
$showForm = isset($_GET['new']) || $editId > 0;

if ($editId > 0) {
    $es = $pdo->prepare("SELECT * FROM champions WHERE id = ?");
    $es->execute([$editId]);
    $editing = $es->fetch();
    if (!$editing) {
        redirect('champions.php');
    }
}

$champions = $pdo->query("
    SELECT c.id, c.name, c.title, c.country, c.profileimg, s.name AS sport_name, s.icon AS sport_icon
    FROM champions c JOIN sports s ON c.sport_id = s.id
    ORDER BY c.id DESC
")->fetchAll();

$success = flash('success');
$error   = flash('error');

$page_title = 'مدیریت قهرمانان — پنل مدیریت';
include __DIR__ . '/_header.php';
?>

<div class="admin-topbar">
    <div>
        <h1>مدیریت قهرمانان</h1>
        <p><?= toPersianDigits(count($champions)) ?> قهرمان در حال حاضر ثبت شده است.</p>
    </div>
    <?php if (!$showForm): ?>
        <a href="champions.php?new=1" class="btn btn-primary">+ افزودن قهرمان جدید</a>
    <?php else: ?>
        <a href="champions.php" class="btn btn-ghost">بازگشت به فهرست</a>
    <?php endif; ?>
</div>

<?php if ($success): ?>
    <div class="form-message success" role="status"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" aria-hidden="true"><path d="M20 6 9 17l-5-5"/></svg><span><?= e($success) ?></span></div>
<?php endif; ?>
<?php if ($error): ?>
    <div class="form-message error" role="alert"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" aria-hidden="true"><circle cx="12" cy="12" r="10"/><path d="M12 8v4M12 16h.01"/></svg><span><?= e($error) ?></span></div>
<?php endif; ?>

<?php if ($showForm): ?>
    <!-- ═══════════ فرم افزودن/ویرایش ═══════════ -->
    <section class="admin-panel-card">
        <div class="admin-panel-head">
            <h2><?= $editing ? 'ویرایش قهرمان' : 'افزودن قهرمان جدید' ?></h2>
        </div>
        <form method="POST">
            <?= csrfField() ?>
            <input type="hidden" name="id" value="<?= e($editing['id'] ?? 0) ?>">

            <div class="form-row">
                <div class="form-group">
                    <label class="form-label" for="ch_name">نام قهرمان</label>
                    <input type="text" id="ch_name" name="name" class="form-control" required
                           value="<?= e($editing['name'] ?? '') ?>">
                </div>
                <div class="form-group">
                    <label class="form-label" for="ch_sport">رشتهٔ ورزشی</label>
                    <select id="ch_sport" name="sport_id" class="form-control" required>
                        <option value="">انتخاب کن…</option>
                        <?php foreach ($sports as $sp): ?>
                            <option value="<?= e($sp['id']) ?>" <?= ($editing['sport_id'] ?? 0) == $sp['id'] ? 'selected' : '' ?>>
                                <?= e($sp['icon']) ?> <?= e($sp['name']) ?>
                            </option>
                        <?php endforeach; ?>
                    </select>
                </div>
            </div>

            <div class="form-row">
                <div class="form-group">
                    <label class="form-label" for="ch_country">کشور</label>
                    <input type="text" id="ch_country" name="country" class="form-control"
                           value="<?= e($editing['country'] ?? 'ایران') ?>">
                </div>
                <div class="form-group">
                    <label class="form-label" for="ch_title">لقب / افتخار</label>
                    <input type="text" id="ch_title" name="title" class="form-control"
                           placeholder="مثلاً قهرمان المپیک" value="<?= e($editing['title'] ?? '') ?>">
                </div>
            </div>

            <div class="form-group">
                <label class="form-label" for="ch_img">آدرس عکس پروفایل (اختیاری)</label>
                <input type="url" id="ch_img" name="profileimg" class="form-control"
                       placeholder="https://…" value="<?= e($editing['profileimg'] ?? '') ?>">
                <small class="hint">اگر خالی بماند، حرف اول نام به‌جای عکس نمایش داده می‌شود.</small>
            </div>

            <div class="form-group">
                <label class="form-label" for="ch_bio">بیوگرافی</label>
                <textarea id="ch_bio" name="bio" class="form-control" rows="4"><?= e($editing['bio'] ?? '') ?></textarea>
            </div>

            <button type="submit" name="save_champion" value="1" class="btn btn-primary">
                <?= $editing ? 'ذخیرهٔ تغییرات' : 'افزودن قهرمان' ?>
            </button>
        </form>
    </section>
<?php else: ?>
    <!-- ═══════════ فهرست قهرمانان ═══════════ -->
    <section class="admin-panel-card">
        <div class="admin-table-wrap">
            <table class="admin-table">
                <thead>
                    <tr><th>نام</th><th>رشته</th><th>کشور</th><th>لقب</th><th></th></tr>
                </thead>
                <tbody>
                    <?php foreach ($champions as $c): ?>
                        <tr>
                            <td><a href="../champion.php?id=<?= e($c['id']) ?>" target="_blank"><?= e($c['name']) ?></a></td>
                            <td><?= e($c['sport_icon']) ?> <?= e($c['sport_name']) ?></td>
                            <td><?= e($c['country']) ?></td>
                            <td><?= e($c['title'] ?? '—') ?></td>
                            <td class="admin-table-actions">
                                <a href="champions.php?edit=<?= e($c['id']) ?>" class="btn btn-ghost btn-sm">ویرایش</a>
                                <form method="POST" data-confirm="آیا از حذف «<?= e($c['name']) ?>» مطمئن هستی؟">
                                    <?= csrfField() ?>
                                    <input type="hidden" name="id" value="<?= e($c['id']) ?>">
                                    <button type="submit" name="delete_champion" value="1" class="btn btn-danger btn-sm">حذف</button>
                                </form>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        </div>
    </section>
<?php endif; ?>

<?php include __DIR__ . '/_footer.php'; ?>
