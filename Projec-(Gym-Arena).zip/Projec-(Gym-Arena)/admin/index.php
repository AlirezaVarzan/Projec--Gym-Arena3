<?php
/**
 * ═══════════════════════════════════════════════════════════
 *  پنل مدیریت — نمای کلی
 * ═══════════════════════════════════════════════════════════
 */
require_once __DIR__ . '/../config.php';
requireAdmin();

$stats = $pdo->query("
    SELECT
        (SELECT COUNT(*) FROM users)      AS total_users,
        (SELECT COUNT(*) FROM clubs)      AS total_clubs,
        (SELECT COUNT(*) FROM champions)  AS total_champions,
        (SELECT COUNT(*) FROM reviews)    AS total_reviews,
        (SELECT COUNT(*) FROM favorites)  AS total_favorites
")->fetch();

// جدیدترین کاربران
$recentUsers = $pdo->query("
    SELECT u.id, u.full_name, u.username, u.city, u.created_at, s.name AS sport_name, s.icon AS sport_icon
    FROM users u
    LEFT JOIN sports s ON u.favorite_sport = s.id
    ORDER BY u.created_at DESC
    LIMIT 8
")->fetchAll();

// جدیدترین نظرات
$recentReviews = $pdo->query("
    SELECT r.rating, r.comment, r.created_at, u.full_name, c.name AS club_name, c.id AS club_id
    FROM reviews r
    JOIN users u ON r.user_id = u.id
    JOIN clubs c ON r.club_id = c.id
    ORDER BY r.created_at DESC
    LIMIT 6
")->fetchAll();

$page_title = 'نمای کلی — پنل مدیریت';
include __DIR__ . '/_header.php';
?>

<div class="admin-topbar">
    <div>
        <h1>نمای کلی</h1>
        <p>سلام <?= e($_SESSION['username'] ?? '') ?>، خلاصهٔ وضعیت آرِنا را اینجا می‌بینی.</p>
    </div>
</div>

<div class="admin-stat-grid">
    <div class="admin-stat-card">
        <span class="ico-emoji" aria-hidden="true">👥</span>
        <div><strong><?= toPersianDigits($stats['total_users']) ?></strong><span>کاربر ثبت‌نامی</span></div>
    </div>
    <div class="admin-stat-card">
        <span class="ico-emoji" aria-hidden="true">🏟️</span>
        <div><strong><?= toPersianDigits($stats['total_clubs']) ?></strong><span>باشگاه فعال</span></div>
    </div>
    <div class="admin-stat-card">
        <span class="ico-emoji" aria-hidden="true">🏆</span>
        <div><strong><?= toPersianDigits($stats['total_champions']) ?></strong><span>قهرمان ثبت‌شده</span></div>
    </div>
    <div class="admin-stat-card">
        <span class="ico-emoji" aria-hidden="true">✍️</span>
        <div><strong><?= toPersianDigits($stats['total_reviews']) ?></strong><span>نظر کاربران</span></div>
    </div>
    <div class="admin-stat-card">
        <span class="ico-emoji" aria-hidden="true">❤</span>
        <div><strong><?= toPersianDigits($stats['total_favorites']) ?></strong><span>علاقه‌مندی ثبت‌شده</span></div>
    </div>
</div>

<div class="admin-columns">

    <section class="admin-panel-card">
        <div class="admin-panel-head">
            <h2>جدیدترین کاربران</h2>
            <a href="users.php" class="btn btn-ghost btn-sm">مشاهدهٔ همه</a>
        </div>
        <?php if (!$recentUsers): ?>
            <p class="hint">هنوز کاربری ثبت‌نام نکرده است.</p>
        <?php else: ?>
            <div class="admin-table-wrap">
                <table class="admin-table">
                    <thead>
                        <tr><th>نام</th><th>شهر</th><th>رشته</th><th>تاریخ عضویت</th></tr>
                    </thead>
                    <tbody>
                        <?php foreach ($recentUsers as $u): ?>
                            <tr>
                                <td><?= e($u['full_name']) ?><br><span class="admin-td-sub">@<?= e($u['username']) ?></span></td>
                                <td><?= e($u['city']) ?></td>
                                <td><?= e($u['sport_icon'] ?? '—') ?> <?= e($u['sport_name'] ?? '') ?></td>
                                <td><?= e(toPersianDigits(date('Y/m/d', strtotime($u['created_at'])))) ?></td>
                            </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
        <?php endif; ?>
    </section>

    <section class="admin-panel-card">
        <div class="admin-panel-head">
            <h2>جدیدترین نظرات</h2>
        </div>
        <?php if (!$recentReviews): ?>
            <p class="hint">هنوز نظری ثبت نشده است.</p>
        <?php else: ?>
            <div class="admin-review-list">
                <?php foreach ($recentReviews as $rv): ?>
                    <article class="admin-review-item">
                        <div class="admin-review-head">
                            <strong><?= e($rv['full_name']) ?></strong>
                            <span class="stars" aria-hidden="true"><?= str_repeat('★', (int) $rv['rating']) . str_repeat('☆', 5 - (int) $rv['rating']) ?></span>
                        </div>
                        <p>درباره: <a href="../club.php?id=<?= e($rv['club_id']) ?>"><?= e($rv['club_name']) ?></a></p>
                        <?php if (!empty($rv['comment'])): ?>
                            <p class="admin-td-sub"><?= e($rv['comment']) ?></p>
                        <?php endif; ?>
                    </article>
                <?php endforeach; ?>
            </div>
        <?php endif; ?>
    </section>

</div>

<?php include __DIR__ . '/_footer.php'; ?>
