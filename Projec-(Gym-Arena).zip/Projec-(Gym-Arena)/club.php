<?php
/**
 * ═══════════════════════════════════════════════════════════
 *  صفحهٔ جزئیات باشگاه
 *  شامل: اطلاعات کامل، امتیاز، نظرات کاربران و دکمهٔ علاقه‌مندی
 * ═══════════════════════════════════════════════════════════
 */
require_once __DIR__ . '/config.php';

$club_id = (int) ($_GET['id'] ?? 0);

if ($club_id <= 0) {
    redirect('clubs.php');
}

/* ═══════════════════════════════════════════════════════════
   بخش ۱ — پردازش فرم ثبت نظر (باید قبل از خواندن نظرات اجرا شود)
   ═══════════════════════════════════════════════════════════ */
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['submit_review'])) {

    requireLogin();
    verifyCsrf();

    $rating  = (int) ($_POST['rating'] ?? 0);
    $comment = trim((string) ($_POST['comment'] ?? ''));

    if ($rating < 1 || $rating > 5) {
        flash('error', 'لطفاً امتیازی بین ۱ تا ۵ ستاره انتخاب کن.');
    } elseif (mb_strlen($comment) > 500) {
        flash('error', 'نظر شما نباید بیشتر از ۵۰۰ کاراکتر باشد.');
    } else {
        // هر کاربر فقط یک نظر برای هر باشگاه دارد؛ نظر قبلی به‌روزرسانی می‌شود
        $stmt = $pdo->prepare("
            INSERT INTO reviews (club_id, user_id, rating, comment)
            VALUES (?, ?, ?, ?)
            ON DUPLICATE KEY UPDATE rating = VALUES(rating), comment = VALUES(comment), created_at = CURRENT_TIMESTAMP
        ");
        $stmt->execute([$club_id, $_SESSION['user_id'], $rating, $comment !== '' ? $comment : null]);

        // میانگین امتیاز باشگاه را بر اساس همهٔ نظرات به‌روزرسانی کن
        $avg = $pdo->prepare("SELECT AVG(rating) AS avg_rating FROM reviews WHERE club_id = ?");
        $avg->execute([$club_id]);
        $avgRating = (float) $avg->fetch()['avg_rating'];

        $pdo->prepare("UPDATE clubs SET rating = ? WHERE id = ?")
            ->execute([round($avgRating, 1), $club_id]);

        flash('success', 'نظر شما با موفقیت ثبت شد. سپاسگزاریم!');
    }

    redirect('club.php?id=' . $club_id);
}

/* ═══════════════════════════════════════════════════════════
   بخش ۲ — تغییر وضعیت علاقه‌مندی (افزودن/حذف)
   ═══════════════════════════════════════════════════════════ */
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['toggle_favorite'])) {

    requireLogin();
    verifyCsrf();

    $check = $pdo->prepare("SELECT id FROM favorites WHERE user_id = ? AND club_id = ?");
    $check->execute([$_SESSION['user_id'], $club_id]);

    if ($check->fetch()) {
        $pdo->prepare("DELETE FROM favorites WHERE user_id = ? AND club_id = ?")
            ->execute([$_SESSION['user_id'], $club_id]);
        flash('success', 'از علاقه‌مندی‌ها حذف شد.');
    } else {
        $pdo->prepare("INSERT INTO favorites (user_id, club_id) VALUES (?, ?)")
            ->execute([$_SESSION['user_id'], $club_id]);
        flash('success', 'به علاقه‌مندی‌های تو اضافه شد ❤');
    }

    redirect('club.php?id=' . $club_id);
}

/* ═══════════════════════════════════════════════════════════
   بخش ۳ — دریافت اطلاعات باشگاه
   ═══════════════════════════════════════════════════════════ */
$stmt = $pdo->prepare("
    SELECT c.*, s.name AS sport_name, s.icon AS sport_icon
    FROM clubs c
    JOIN sports s ON c.sport_id = s.id
    WHERE c.id = ?
    LIMIT 1
");
$stmt->execute([$club_id]);
$club = $stmt->fetch();

if (!$club) {
    http_response_code(404);
    $page_title = 'باشگاه پیدا نشد — آرِنا';
    include __DIR__ . '/header.php';
    echo '<div class="container"><div class="empty-state"><span class="icon">🚫</span><p>چنین باشگاهی پیدا نشد.</p>'
        . '<p class="hint"><a href="clubs.php">بازگشت به فهرست باشگاه‌ها</a></p></div></div>';
    include __DIR__ . '/footer.php';
    exit;
}

// نظرات این باشگاه به همراه نام نویسندهٔ آن‌ها
$reviewsStmt = $pdo->prepare("
    SELECT r.rating, r.comment, r.created_at, u.full_name
    FROM reviews r
    JOIN users u ON r.user_id = u.id
    WHERE r.club_id = ?
    ORDER BY r.created_at DESC
");
$reviewsStmt->execute([$club_id]);
$reviews = $reviewsStmt->fetchAll();

$is_favorite = false;
if (isLoggedIn()) {
    $favCheck = $pdo->prepare("SELECT id FROM favorites WHERE user_id = ? AND club_id = ?");
    $favCheck->execute([$_SESSION['user_id'], $club_id]);
    $is_favorite = (bool) $favCheck->fetch();
}

// باشگاه‌های مشابه (همان رشته، شهر متفاوت یا یکسان)، برای کشف بیشتر
$similarStmt = $pdo->prepare("
    SELECT id, name, city, rating
    FROM clubs
    WHERE sport_id = ? AND id <> ?
    ORDER BY rating DESC
    LIMIT 4
");
$similarStmt->execute([$club['sport_id'], $club_id]);
$similar = $similarStmt->fetchAll();

$success = flash('success');
$error   = flash('error');

$page_title = $club['name'] . ' — آرِنا';

include __DIR__ . '/header.php';
?>

<div class="container">

    <a href="clubs.php" class="back-link">→ بازگشت به فهرست باشگاه‌ها</a>

    <!-- ═══════════ سربرگ باشگاه ═══════════ -->
    <section class="club-detail-hero">
        <div class="club-detail-icon" aria-hidden="true"><?= e($club['sport_icon']) ?></div>
        <div class="club-detail-info">
            <h1><?= e($club['name']) ?></h1>
            <div class="club-rating club-rating-lg">
                <span class="stars" aria-hidden="true"><?= str_repeat('★', (int) round((float) $club['rating'])) . str_repeat('☆', 5 - (int) round((float) $club['rating'])) ?></span>
                <span class="rating-num"><?= toPersianDigits(number_format((float) $club['rating'], 1)) ?></span>
                <span class="rating-count">(<?= toPersianDigits(count($reviews)) ?> نظر)</span>
            </div>
            <p class="club-detail-sport"><?= e($club['sport_icon']) ?> <?= e($club['sport_name']) ?> · 📍 <?= e($club['city']) ?></p>
        </div>

        <?php if (isLoggedIn()): ?>
            <form method="POST" class="fav-form">
                <?= csrfField() ?>
                <button type="submit" name="toggle_favorite" value="1"
                        class="btn <?= $is_favorite ? 'btn-primary' : 'btn-ghost' ?> btn-fav">
                    <?= $is_favorite ? '❤ در علاقه‌مندی‌ها' : '♡ افزودن به علاقه‌مندی‌ها' ?>
                </button>
            </form>
        <?php endif; ?>
    </section>

    <?php if ($success): ?>
        <div class="form-message success" role="status">
            <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" aria-hidden="true"><path d="M20 6 9 17l-5-5"/></svg>
            <span><?= e($success) ?></span>
        </div>
    <?php endif; ?>
    <?php if ($error): ?>
        <div class="form-message error" role="alert">
            <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" aria-hidden="true"><circle cx="12" cy="12" r="10"/><path d="M12 8v4M12 16h.01"/></svg>
            <span><?= e($error) ?></span>
        </div>
    <?php endif; ?>

    <div class="club-detail-grid">

        <!-- ─── ستون اصلی: توضیحات و نظرات ─── -->
        <div class="club-detail-main">

            <?php if (!empty($club['description'])): ?>
                <section class="section-compact">
                    <h2 class="subsection-title">دربارهٔ باشگاه</h2>
                    <p class="club-description"><?= e($club['description']) ?></p>
                </section>
            <?php endif; ?>

            <section class="section-compact" id="reviews">
                <h2 class="subsection-title">نظرات ورزشکاران (<?= toPersianDigits(count($reviews)) ?>)</h2>

                <?php if (isLoggedIn()): ?>
                    <form method="POST" class="review-form">
                        <?= csrfField() ?>
                        <div class="star-input" data-star-input>
                            <?php for ($i = 5; $i >= 1; $i--): ?>
                                <input type="radio" name="rating" id="star<?= $i ?>" value="<?= $i ?>" required>
                                <label for="star<?= $i ?>" title="<?= toPersianDigits($i) ?> ستاره">★</label>
                            <?php endfor; ?>
                        </div>
                        <textarea name="comment" class="form-control" rows="3"
                                  maxlength="500" placeholder="تجربه‌ات از این باشگاه رو بنویس (اختیاری)…"></textarea>
                        <button type="submit" name="submit_review" value="1" class="btn btn-primary">
                            ثبت نظر
                        </button>
                    </form>
                <?php else: ?>
                    <div class="empty-state empty-state-compact">
                        <p>برای ثبت نظر باید <a href="signup.php">وارد شوی</a> یا <a href="register.php">ثبت‌نام کنی</a>.</p>
                    </div>
                <?php endif; ?>

                <?php if (!$reviews): ?>
                    <p class="hint" style="margin-top:16px;">هنوز نظری برای این باشگاه ثبت نشده — اولین نفر باش!</p>
                <?php else: ?>
                    <div class="reviews-list">
                        <?php foreach ($reviews as $rv): ?>
                            <article class="review-card">
                                <div class="review-head">
                                    <strong><?= e($rv['full_name']) ?></strong>
                                    <span class="stars" aria-hidden="true"><?= str_repeat('★', (int) $rv['rating']) . str_repeat('☆', 5 - (int) $rv['rating']) ?></span>
                                </div>
                                <?php if (!empty($rv['comment'])): ?>
                                    <p><?= e($rv['comment']) ?></p>
                                <?php endif; ?>
                            </article>
                        <?php endforeach; ?>
                    </div>
                <?php endif; ?>
            </section>
        </div>

        <!-- ─── ستون کناری: مشخصات کلی ─── -->
        <aside class="club-detail-side">
            <h2 class="subsection-title">مشخصات باشگاه</h2>
            <ul class="club-facts">
                <?php if (!empty($club['address'])): ?>
                    <li><span class="fact-ico">📍</span><div><strong>آدرس</strong><br><?= e($club['address']) ?></div></li>
                <?php endif; ?>
                <?php if (!empty($club['phone'])): ?>
                    <li><span class="fact-ico">☎</span><div><strong>تلفن تماس</strong><br><?= e($club['phone']) ?></div></li>
                <?php endif; ?>
                <?php if (!empty($club['working_hours'])): ?>
                    <li><span class="fact-ico">🕒</span><div><strong>ساعات کاری</strong><br><?= e($club['working_hours']) ?></div></li>
                <?php endif; ?>
                <?php if (!empty($club['price_monthly'])): ?>
                    <li><span class="fact-ico">💳</span><div><strong>هزینهٔ ماهانه</strong><br><?= toPersianDigits(number_format((int) $club['price_monthly'])) ?> تومان</div></li>
                <?php endif; ?>
                <?php if (!empty($club['capacity'])): ?>
                    <li><span class="fact-ico">👥</span><div><strong>ظرفیت</strong><br><?= toPersianDigits($club['capacity']) ?> نفر هم‌زمان</div></li>
                <?php endif; ?>
                <?php if (!empty($club['established_year'])): ?>
                    <li><span class="fact-ico">📅</span><div><strong>سال تأسیس</strong><br><?= toPersianDigits($club['established_year']) ?></div></li>
                <?php endif; ?>
                <?php if (!empty($club['instagram'])): ?>
                    <li><span class="fact-ico">📷</span><div><strong>اینستاگرام</strong><br><?= e($club['instagram']) ?></div></li>
                <?php endif; ?>
            </ul>

            <?php if ($similar): ?>
                <h2 class="subsection-title" style="margin-top:32px;">باشگاه‌های مشابه</h2>
                <div class="similar-clubs">
                    <?php foreach ($similar as $s): ?>
                        <a class="similar-club" href="club.php?id=<?= e($s['id']) ?>">
                            <span><?= e($s['name']) ?></span>
                            <span class="similar-club-meta">📍 <?= e($s['city']) ?> · ⭐ <?= toPersianDigits(number_format((float) $s['rating'], 1)) ?></span>
                        </a>
                    <?php endforeach; ?>
                </div>
            <?php endif; ?>
        </aside>

    </div>
</div>

<?php include __DIR__ . '/footer.php'; ?>
