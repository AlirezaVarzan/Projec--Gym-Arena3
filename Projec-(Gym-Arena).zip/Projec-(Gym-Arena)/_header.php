<?php
/**
 * ═══════════════════════════════════════════════════════════
 *  پنل مدیریت — هدر مشترک
 *  پیش‌نیاز: config.php باید قبلاً require شده و requireAdmin()
 *  فراخوانی شده باشد (در هر فایل صفحهٔ ادمین انجام می‌شود).
 * ═══════════════════════════════════════════════════════════
 */
$admin_page = basename($_SERVER['PHP_SELF']);
$page_title = $page_title ?? 'پنل مدیریت — آرِنا';
?>
<!DOCTYPE html>
<html lang="fa" dir="rtl">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, viewport-fit=cover">
    <meta name="theme-color" content="#0a0b10">
    <title><?= e($page_title) ?></title>
    <link rel="preload" href="../Vazir.woff2" as="font" type="font/woff2" crossorigin>
    <link rel="stylesheet" href="../style.css?v=3.0">
</head>
<body class="admin-body">

<div class="admin-shell">

    <!-- ═══════════ نوار کناری ═══════════ -->
    <aside class="admin-sidebar">
        <a href="../index.php" class="logo admin-logo" aria-label="آرِنا — صفحهٔ اصلی">
            <span class="logo-mark" aria-hidden="true">آ</span>
            <span class="logo-text">آرِنا<span class="accent">.</span></span>
        </a>
        <div class="admin-sidebar-tag">پنل مدیریت</div>

        <nav class="admin-nav" aria-label="ناوبری مدیریت">
            <a href="index.php" class="<?= $admin_page === 'index.php' ? 'is-active' : '' ?>">
                <span aria-hidden="true">📊</span> نمای کلی
            </a>
            <a href="clubs.php" class="<?= $admin_page === 'clubs.php' ? 'is-active' : '' ?>">
                <span aria-hidden="true">🏟️</span> باشگاه‌ها
            </a>
            <a href="champions.php" class="<?= $admin_page === 'champions.php' ? 'is-active' : '' ?>">
                <span aria-hidden="true">🏆</span> قهرمانان
            </a>
            <a href="users.php" class="<?= $admin_page === 'users.php' ? 'is-active' : '' ?>">
                <span aria-hidden="true">👥</span> کاربران
            </a>
        </nav>

        <div class="admin-sidebar-foot">
            <a href="../dashboard.php" class="btn btn-ghost btn-sm btn-block">بازگشت به سایت</a>
            <a href="../logout.php" class="btn btn-primary btn-sm btn-block">خروج از حساب</a>
        </div>
    </aside>

    <!-- ═══════════ محتوای اصلی ═══════════ -->
    <main class="admin-main">
