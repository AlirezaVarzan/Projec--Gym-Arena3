<?php
/**
 * ═══════════════════════════════════════════════════════════
 *  پردازش فرم ثبت‌نام
 * ───────────────────────────────────────────────────────────
 *  بهینه‌سازی نسبت به نسخهٔ قبل:
 *   • به‌جای ۱۰ بلوکِ تکراری if+redirect، خطاها در یک آرایه
 *     جمع می‌شوند و کاربر همهٔ ایرادها را یک‌جا می‌بیند.
 *   • بررسی واقعی معتبر بودن تاریخ (نه فقط قالب آن).
 *   • جلوگیری از Session Fixation و محافظت CSRF.
 * ═══════════════════════════════════════════════════════════
 */
require_once __DIR__ . '/config.php';

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    redirect('register.php');
}

verifyCsrf();

/* ═══════════════════════════════════════════════════════════
   توابع اعتبارسنجی اختصاصی
   ═══════════════════════════════════════════════════════════ */

/**
 * اعتبارسنجی کد ملی ایران بر اساس الگوریتم رقم کنترلی.
 */
function isValidIranianNationalCode(string $code): bool
{
    $code = toEnglishDigits($code);

    // باید دقیقاً ۱۰ رقم باشد
    if (!preg_match('/^\d{10}$/', $code)) {
        return false;
    }

    // کدهایی مثل 1111111111 معتبر نیستند
    if (preg_match('/^(\d)\1{9}$/', $code)) {
        return false;
    }

    // محاسبهٔ جمع وزنی ۹ رقم اول
    $sum = 0;
    for ($i = 0; $i < 9; $i++) {
        $sum += (int) $code[$i] * (10 - $i);
    }

    $remainder = $sum % 11;
    $check     = (int) $code[9]; // رقم کنترلی

    return ($remainder < 2 && $check === $remainder)
        || ($remainder >= 2 && $check === (11 - $remainder));
}

/**
 * بررسی اینکه رشتهٔ ورودی یک تاریخ میلادی واقعی و معتبر است.
 * (مثلاً 2024-02-31 از نظر قالب درست ولی از نظر تقویم غلط است.)
 */
function isRealDate(string $date): bool
{
    $d = DateTime::createFromFormat('Y-m-d', $date);
    return $d !== false && $d->format('Y-m-d') === $date;
}

/* ═══════════════════════════════════════════════════════════
   دریافت و پاک‌سازی ورودی‌ها
   ═══════════════════════════════════════════════════════════ */
$full_name        = trim($_POST['full_name'] ?? '');
$national_code    = toEnglishDigits(trim($_POST['national_code'] ?? ''));
$birth_date       = trim($_POST['birth_date'] ?? '');
$age              = (int) toEnglishDigits((string) ($_POST['age'] ?? '0'));
$favorite_sport   = (int) ($_POST['favorite_sport'] ?? 0);
$city             = trim($_POST['city'] ?? '');
$username         = trim($_POST['username'] ?? '');
$password         = (string) ($_POST['password'] ?? '');
$password_confirm = (string) ($_POST['password_confirm'] ?? '');

// نگه‌داشتن مقادیر برای پر کردن مجدد فرم در صورت خطا (رمز عبور ذخیره نمی‌شود)
flash('old', [
    'full_name'      => $full_name,
    'national_code'  => $national_code,
    'birth_date'     => $birth_date,
    'age'            => $age,
    'favorite_sport' => $favorite_sport,
    'city'           => $city,
    'username'       => $username,
]);

/* ═══════════════════════════════════════════════════════════
   اعتبارسنجی — همهٔ خطاها یک‌جا جمع می‌شوند
   ═══════════════════════════════════════════════════════════ */
$errors = [];

if (mb_strlen($full_name) < 3) {
    $errors[] = 'نام و نام خانوادگی باید حداقل ۳ کاراکتر باشد.';
}

if (!isValidIranianNationalCode($national_code)) {
    $errors[] = 'کد ملی وارد شده معتبر نیست.';
}

if (!isRealDate($birth_date)) {
    $errors[] = 'تاریخ تولد معتبر وارد کنید.';
} elseif (strtotime($birth_date) > time()) {
    // تاریخ تولد نمی‌تواند در آینده باشد
    $errors[] = 'تاریخ تولد نمی‌تواند در آینده باشد.';
}

if ($age < 6 || $age > 100) {
    $errors[] = 'سن باید بین ۶ تا ۱۰۰ سال باشد.';
}

if ($favorite_sport <= 0) {
    $errors[] = 'لطفاً رشتهٔ ورزشی مورد علاقه را انتخاب کنید.';
}

if (mb_strlen($city) < 2) {
    $errors[] = 'لطفاً نام شهر را به‌درستی وارد کنید.';
}

if (!preg_match('/^[a-zA-Z0-9_]{4,60}$/', $username)) {
    $errors[] = 'نام کاربری باید فقط شامل حروف انگلیسی، عدد و خط زیر و حداقل ۴ کاراکتر باشد.';
}

if (mb_strlen($password) < 6) {
    $errors[] = 'رمز عبور باید حداقل ۶ کاراکتر باشد.';
}

if ($password !== $password_confirm) {
    $errors[] = 'رمز عبور و تکرار آن یکسان نیستند.';
}

// اگر تا اینجا خطایی وجود داشت، برگرد و همهٔ خطاها را نشان بده
if ($errors) {
    flash('error', implode(' ', $errors));
    redirect('register.php');
}

/* ═══════════════════════════════════════════════════════════
   بررسی‌های مربوط به دیتابیس
   ═══════════════════════════════════════════════════════════ */

// آیا رشتهٔ ورزشی انتخاب‌شده واقعاً وجود دارد؟
$sportCheck = $pdo->prepare("SELECT id FROM sports WHERE id = ? LIMIT 1");
$sportCheck->execute([$favorite_sport]);

if (!$sportCheck->fetch()) {
    flash('error', 'رشتهٔ ورزشی انتخاب‌شده معتبر نیست.');
    redirect('register.php');
}

// آیا کد ملی یا نام کاربری قبلاً ثبت شده است؟
$dupe = $pdo->prepare("SELECT id FROM users WHERE national_code = ? OR username = ? LIMIT 1");
$dupe->execute([$national_code, $username]);

if ($dupe->fetch()) {
    flash('error', 'کاربری با این کد ملی یا نام کاربری قبلاً ثبت‌نام کرده است.');
    redirect('register.php');
}

/* ═══════════════════════════════════════════════════════════
   درج کاربر جدید
   ═══════════════════════════════════════════════════════════ */

// PASSWORD_DEFAULT همیشه از بهترین الگوریتم روز استفاده می‌کند
$hash = password_hash($password, PASSWORD_DEFAULT);

try {
    $insert = $pdo->prepare("
        INSERT INTO users
            (full_name, national_code, birth_date, age, favorite_sport, city, username, password)
        VALUES (?, ?, ?, ?, ?, ?, ?, ?)
    ");
    $insert->execute([
        $full_name, $national_code, $birth_date, $age,
        $favorite_sport, $city, $username, $hash,
    ]);

} catch (PDOException $e) {
    // کد 23000 یعنی نقض قید یکتایی (Duplicate Entry) — احتمال ثبت هم‌زمان دو کاربر
    if ($e->getCode() === '23000') {
        flash('error', 'کاربری با این کد ملی یا نام کاربری قبلاً ثبت‌نام کرده است.');
        redirect('register.php');
    }
    throw $e;
}

/* ─── ورود خودکار کاربر تازه ثبت‌نام‌شده ─────────────────── */
session_regenerate_id(true); // جلوگیری از Session Fixation

$_SESSION['user_id']  = (int) $pdo->lastInsertId();
$_SESSION['username'] = $username;
$_SESSION['is_admin'] = false;

unset($_SESSION['flash']);

redirect('dashboard.php');
