<?php
/**
 * ═══════════════════════════════════════════════════════════
 *  صفحهٔ اصلی (Landing)
 *  اگر کاربر از قبل وارد شده باشد، مستقیم به داشبورد می‌رود.
 * ═══════════════════════════════════════════════════════════
 */
require_once __DIR__ . '/config.php';

// کاربر واردشده نیازی به صفحهٔ معرفی ندارد
if (isLoggedIn()) {
    redirect('dashboard.php');
}

$page_title = 'آرِنا — پلتفرم ورزشکاران ایران';

/* ─── دریافت داده‌ها از دیتابیس ─────────────────────────────
   تمام آمار در «یک» کوئری گرفته می‌شود تا رفت‌وبرگشت به
   دیتابیس کاهش پیدا کند (بهینه‌سازی نسبت به نسخهٔ قبلی).     */
$sports = $pdo->query("SELECT id, name, icon FROM sports ORDER BY id ASC")->fetchAll();

// شش قهرمان تصادفی برای پیش‌نمایش
$preview_champions = $pdo->query("
    SELECT c.name, c.title, c.bio, c.country, c.profileimg,
           s.name AS sport_name, s.icon AS sport_icon
    FROM champions c
    JOIN sports s ON c.sport_id = s.id
    ORDER BY RAND()
    LIMIT 6
")->fetchAll();

// آمار کلی سایت — با یک کوئری واحد به‌جای سه کوئری جداگانه
$stats = $pdo->query("
    SELECT
        (SELECT COUNT(*) FROM champions) AS total_champs,
        (SELECT COUNT(*) FROM clubs)     AS total_clubs,
        (SELECT COUNT(*) FROM users)     AS total_users
")->fetch();

$total_champs = (int) $stats['total_champs'];
$total_clubs  = (int) $stats['total_clubs'];
$total_sports = count($sports);

include __DIR__ . '/header.php';
?>

<!-- ═══════════ بخش معرفی (Hero) ═══════════ -->
<section class="hero">
    <!-- لکه‌های نورانی پس‌زمینه (تزئینی) -->
    <div class="hero-blob" aria-hidden="true"></div>
    <div class="hero-grid-lines" aria-hidden="true"></div>

    <div class="container">
        <div class="hero-grid">

            <!-- ستون متن -->
            <div class="hero-content">
                <div class="hero-eyebrow">
                    <span class="dot" aria-hidden="true"></span>
                    <span>پلتفرم ورزشکاران ایران</span>
                </div>

                <h1 class="hero-title">
                    قهرمانانت را
                    <span class="accent">بشناس</span>
                    و باشگاهت را
                    <span class="accent">پیدا کن</span>
                </h1>

                <p class="hero-subtitle">
                    در آرِنا با بزرگان رشتهٔ ورزشی محبوبت آشنا شو، الگو بگیر و
                    باشگاه‌های فعال شهر خودت را در یک نگاه پیدا کن —
                    از بدنسازی تا والیبال، از تبریز تا بندرعباس.
                </p>

                <!-- دکمه‌های اصلی؛ پاپ‌آپ ثبت‌نام/ورود را باز می‌کنند -->
                <div class="hero-cta">
                    <button type="button" class="btn btn-primary btn-lg" data-open-modal="register">
                        <span>شروع کن — رایگان</span>
                        <svg class="btn-ico" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">
                            <path d="M16 21v-2a4 4 0 0 0-4-4H6a4 4 0 0 0-4 4v2"/><circle cx="9" cy="7" r="4"/><path d="M19 8v6"/><path d="M22 11h-6"/>
                        </svg>
                    </button>
                    <button type="button" class="btn btn-ghost btn-lg" data-open-modal="login">
                        <span>ورود</span>
                        <svg class="btn-ico" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">
                            <path d="M15 3h4a2 2 0 0 1 2 2v14a2 2 0 0 1-2 2h-4"/><polyline points="10 17 15 12 10 7"/><line x1="15" y1="12" x2="3" y2="12"/>
                        </svg>
                    </button>
                </div>

                <!-- آمار سایت — اعداد با انیمیشن شمارش بالا می‌روند (app.js) -->
                <div class="hero-stats">
                    <div class="stat">
                        <div class="stat-num" data-count="<?= $total_champs ?>">۰</div>
                        <div class="stat-label">قهرمان ثبت‌شده</div>
                    </div>
                    <div class="stat">
                        <div class="stat-num" data-count="<?= $total_clubs ?>">۰</div>
                        <div class="stat-label">باشگاه فعال</div>
                    </div>
                    <div class="stat">
                        <div class="stat-num" data-count="<?= $total_sports ?>">۰</div>
                        <div class="stat-label">رشتهٔ ورزشی</div>
                    </div>
                </div>
            </div>

            <!-- ستون کارت‌های شناور (در موبایل مخفی می‌شود) -->
            <div class="hero-visual" aria-hidden="true">
                <div class="hero-card card-1">
                    <div class="card-icon">💪</div>
                    <h4>هادی چوپان</h4>
                    <p>قهرمان مستر المپیا — افتخار ایران در بدنسازی جهان</p>
                </div>
                <div class="hero-card card-2">
                    <div class="card-icon">🏆</div>
                    <h4>حسن یزدانی</h4>
                    <p>پلنگ مازندران — قهرمان المپیک کشتی آزاد</p>
                </div>
                <div class="hero-card card-3">
                    <div class="card-icon">⚽</div>
                    <h4>علی دایی</h4>
                    <p>بهترین گلزن ملی جهان با ۱۰۹ گل</p>
                </div>
            </div>

        </div>
    </div>
</section>

<!-- ═══════════ رشته‌های ورزشی ═══════════ -->
<section class="section" id="sports">
    <div class="container">
        <div class="section-header">
            <div class="section-eyebrow">رشته‌های ورزشی</div>
            <h2 class="section-title">رشته‌ای که عاشقش هستی</h2>
            <p class="section-subtitle">
                رشتهٔ محبوبت را انتخاب کن تا قهرمانان و باشگاه‌های آن را ببینی.
            </p>
        </div>

        <div class="sports-grid reveal-group">
            <?php foreach ($sports as $sport): ?>
                <!-- کلیک روی هر رشته → پاپ‌آپ ثبت‌نام با همان رشتهٔ از پیش انتخاب‌شده -->
                <button type="button" class="sport-card"
                        data-open-modal="register"
                        data-sport="<?= e($sport['id']) ?>">
                    <span class="icon" aria-hidden="true"><?= e($sport['icon']) ?></span>
                    <span class="name"><?= e($sport['name']) ?></span>
                </button>
            <?php endforeach; ?>
        </div>
    </div>
</section>

<!-- ═══════════ پیش‌نمایش قهرمانان ═══════════ -->
<section class="section section-tinted" id="champions">
    <div class="container">
        <div class="section-header">
            <div class="section-eyebrow">قهرمانان</div>
            <h2 class="section-title">با بزرگان آشنا شو</h2>
            <p class="section-subtitle">
                گزیده‌ای از قهرمانان رشته‌های مختلف — برای دیدن فهرست کامل، ثبت‌نام کن.
            </p>
        </div>

        <div class="champions-grid reveal-group">
            <?php foreach ($preview_champions as $champ): ?>
                <article class="champion-card">
                    <div class="champion-avatar">
                        <?php if (!empty($champ['profileimg'])): ?>
                            <!-- loading=lazy → تصویر فقط هنگام نزدیک شدن به دید کاربر لود می‌شود -->
                            <img src="<?= e($champ['profileimg']) ?>"
                                 alt="<?= e($champ['name']) ?>"
                                 loading="lazy" decoding="async">
                        <?php else: ?>
                            <!-- اگر عکسی موجود نبود، حرف اول نام نمایش داده می‌شود -->
                            <span><?= e(initials($champ['name'])) ?></span>
                        <?php endif; ?>
                    </div>

                    <h3 class="champion-name"><?= e($champ['name']) ?></h3>

                    <?php if (!empty($champ['title'])): ?>
                        <div class="champion-title"><?= e($champ['title']) ?></div>
                    <?php endif; ?>

                    <p class="champion-bio"><?= e($champ['bio']) ?></p>

                    <span class="champion-country">
                        <?= e($champ['sport_icon']) ?>
                        <?= e($champ['sport_name']) ?> · <?= e($champ['country']) ?>
                    </span>
                </article>
            <?php endforeach; ?>
        </div>

        <div class="section-cta">
            <button type="button" class="btn btn-primary btn-lg" data-open-modal="register">
                می‌خواهم قهرمانان رشته‌ام را ببینم
            </button>
        </div>
    </div>
</section>

<?php
// پاپ‌آپ ثبت‌نام / ورود ($sports برای پر کردن منوی کشویی لازم است)
include __DIR__ . '/_modal.php';

include __DIR__ . '/footer.php';
