<?php
/**
 * ═══════════════════════════════════════════════════════════
 *  فهرست و جست‌وجوی باشگاه‌ها
 *  همهٔ کاربران (حتی مهمان‌ها) می‌توانند این صفحه را ببینند و
 *  بر اساس رشته، شهر یا نام باشگاه فیلتر کنند.
 * ═══════════════════════════════════════════════════════════
 */
require_once __DIR__ . '/config.php';

$page_title = 'فهرست باشگاه‌ها — آرِنا';

/* ─── خواندن فیلترها از URL (روش GET → قابل بوکمارک و اشتراک‌گذاری) ─── */
$f_sport = isset($_GET['sport']) ? (int) $_GET['sport'] : 0;
$f_city  = trim((string) ($_GET['city'] ?? ''));
$f_q     = trim((string) ($_GET['q'] ?? ''));

$sports = $pdo->query("SELECT id, name, icon FROM sports ORDER BY id ASC")->fetchAll();
$cities = $pdo->query("SELECT DISTINCT city FROM clubs ORDER BY city ASC")->fetchAll(PDO::FETCH_COLUMN);

/* ─── ساخت کوئری پویا بر اساس فیلترهای انتخاب‌شده ─── */
$where  = [];
$params = [];

if ($f_sport > 0) {
    $where[]  = 'c.sport_id = ?';
    $params[] = $f_sport;
}
if ($f_city !== '') {
    $where[]  = 'c.city = ?';
    $params[] = $f_city;
}
if ($f_q !== '') {
    $where[]  = 'c.name LIKE ?';
    $params[] = '%' . $f_q . '%';
}

$sql = "
    SELECT c.id, c.name, c.city, c.address, c.phone, c.rating, c.price_monthly,
           c.working_hours, c.established_year, s.name AS sport_name, s.icon AS sport_icon
    FROM clubs c
    JOIN sports s ON c.sport_id = s.id
";
if ($where) {
    $sql .= ' WHERE ' . implode(' AND ', $where);
}
$sql .= ' ORDER BY c.rating DESC, c.name ASC';

$stmt = $pdo->prepare($sql);
$stmt->execute($params);
$clubs = $stmt->fetchAll();

// آمار سریع برای نوار بالای نتایج
$total_found = count($clubs);

// آیا کاربر واردشده، فهرست علاقه‌مندی‌هایش را دارد؟ (برای نمایش قلب پرشده)
$favorite_ids = [];
if (isLoggedIn()) {
    $favIds = $pdo->prepare("SELECT club_id FROM favorites WHERE user_id = ?");
    $favIds->execute([$_SESSION['user_id']]);
    $favorite_ids = $favIds->fetchAll(PDO::FETCH_COLUMN);
}

include __DIR__ . '/header.php';
?>

<section class="page-hero">
    <div class="container">
        <div class="section-eyebrow">باشگاه‌ها</div>
        <h1 class="section-title">باشگاه رشتهٔ خودت را پیدا کن</h1>
        <p class="section-subtitle">
            از میان <?= toPersianDigits(count($cities)) ?> شهر و
            <?= toPersianDigits(count($sports)) ?> رشتهٔ ورزشی، باشگاه مناسب خودت را جست‌وجو کن.
        </p>
    </div>
</section>

<div class="container">

    <!-- ═══════════ نوار فیلتر جست‌وجو ═══════════ -->
    <form method="GET" class="club-filters">
        <div class="selector-field">
            <label for="f_sport">رشتهٔ ورزشی</label>
            <select id="f_sport" name="sport" class="form-control">
                <option value="0">همهٔ رشته‌ها</option>
                <?php foreach ($sports as $sp): ?>
                    <option value="<?= e($sp['id']) ?>" <?= $f_sport === (int) $sp['id'] ? 'selected' : '' ?>>
                        <?= e($sp['icon']) ?> <?= e($sp['name']) ?>
                    </option>
                <?php endforeach; ?>
            </select>
        </div>

        <div class="selector-field">
            <label for="f_city">شهر</label>
            <select id="f_city" name="city" class="form-control">
                <option value="">همهٔ شهرها</option>
                <?php foreach ($cities as $c): ?>
                    <option value="<?= e($c) ?>" <?= $f_city === $c ? 'selected' : '' ?>><?= e($c) ?></option>
                <?php endforeach; ?>
            </select>
        </div>

        <div class="selector-field selector-field-grow">
            <label for="f_q">جست‌وجوی نام</label>
            <input type="text" id="f_q" name="q" class="form-control"
                   placeholder="مثلاً پرسپولیس، آیرون فیتنس…" value="<?= e($f_q) ?>">
        </div>

        <button type="submit" class="btn btn-primary">جست‌وجو</button>
        <?php if ($f_sport || $f_city || $f_q): ?>
            <a href="clubs.php" class="btn btn-ghost">پاک کردن فیلترها</a>
        <?php endif; ?>
    </form>

    <div class="results-count">
        <?= toPersianDigits($total_found) ?> باشگاه پیدا شد
    </div>

    <!-- ═══════════ نتایج ═══════════ -->
    <?php if (!$clubs): ?>
        <div class="empty-state">
            <span class="icon" aria-hidden="true">🔍</span>
            <p>هیچ باشگاهی با این فیلترها پیدا نشد.</p>
            <p class="hint">فیلترها را تغییر بده یا فیلتر شهر را حذف کن.</p>
        </div>
    <?php else: ?>
        <div class="clubs-grid clubs-grid-detailed reveal-group">
            <?php foreach ($clubs as $club): ?>
                <a class="club-card club-card-link" href="club.php?id=<?= e($club['id']) ?>">
                    <div class="club-icon" aria-hidden="true"><?= e($club['sport_icon']) ?></div>
                    <div class="club-content">
                        <div class="club-name-row">
                            <h3 class="club-name"><?= e($club['name']) ?></h3>
                            <?php if (in_array($club['id'], $favorite_ids)): ?>
                                <span class="fav-indicator" title="در علاقه‌مندی‌ها">❤</span>
                            <?php endif; ?>
                        </div>
                        <div class="club-rating">
                            <span class="stars" aria-hidden="true"><?= str_repeat('★', (int) round($club['rating'])) . str_repeat('☆', 5 - (int) round($club['rating'])) ?></span>
                            <span class="rating-num"><?= toPersianDigits(number_format((float) $club['rating'], 1)) ?></span>
                        </div>
                        <div class="club-meta">
                            <span>📍 <strong><?= e($club['city']) ?></strong> · <?= e($club['sport_name']) ?></span>
                            <?php if (!empty($club['price_monthly'])): ?>
                                <span>💳 <?= toPersianDigits(number_format((int) $club['price_monthly'])) ?> تومان / ماه</span>
                            <?php endif; ?>
                            <?php if (!empty($club['working_hours'])): ?>
                                <span>🕒 <?= e($club['working_hours']) ?></span>
                            <?php endif; ?>
                        </div>
                    </div>
                </a>
            <?php endforeach; ?>
        </div>
    <?php endif; ?>

</div>

<?php include __DIR__ . '/footer.php'; ?>
