/**
 * ═══════════════════════════════════════════════════════════
 *  آرِنا — اسکریپت اصلی (نسخهٔ ۲.۰)
 * ───────────────────────────────────────────────────────────
 *  ماژول‌ها:
 *    ۱. منوی موبایل
 *    ۲. افکت اسکرول هدر + دکمهٔ بازگشت به بالا
 *    ۳. پاپ‌آپ ثبت‌نام/ورود (با قفل فوکوس)
 *    ۴. ظاهر شدن تدریجی کارت‌ها هنگام اسکرول
 *    ۵. انیمیشن شمارش اعداد آمار
 *    ۶. ابزارهای فرم (تبدیل ارقام، محاسبهٔ سن، قدرت رمز و …)
 * ═══════════════════════════════════════════════════════════
 */

(function () {
    'use strict';

    /* ─── ابزارهای کمکی ───────────────────────────────────── */
    const $  = (sel, ctx = document) => ctx.querySelector(sel);
    const $$ = (sel, ctx = document) => Array.from(ctx.querySelectorAll(sel));

    // آیا کاربر «کاهش حرکت» را در سیستم‌عاملش فعال کرده است؟
    const prefersReducedMotion =
        window.matchMedia('(prefers-reduced-motion: reduce)').matches;

    /** تبدیل ارقام لاتین به فارسی — برای نمایش اعداد */
    const toFa = (n) => String(n).replace(/\d/g, (d) => '۰۱۲۳۴۵۶۷۸۹'[d]);

    /** تبدیل ارقام فارسی/عربی به لاتین — برای ورودی‌های عددی */
    const toEn = (str) =>
        String(str)
            .replace(/[۰-۹]/g, (d) => '۰۱۲۳۴۵۶۷۸۹'.indexOf(d))
            .replace(/[٠-٩]/g, (d) => '٠١٢٣٤٥٦٧٨٩'.indexOf(d));

    /** قفل یا آزادسازی اسکرول صفحه (هنگام باز بودن منو یا پاپ‌آپ) */
    const lockScroll = (locked) =>
        document.body.classList.toggle('is-locked', locked);


    /* ═══════════════════════════════════════════════════════
       ۱ · منوی موبایل
       ═══════════════════════════════════════════════════════ */
    (function initMobileNav() {
        const toggle   = $('#navToggle');
        const nav      = $('#mainNav');
        const backdrop = $('#navBackdrop');

        if (!toggle || !nav || !backdrop) return;

        /** باز یا بسته کردن منو */
        function setNav(open) {
            nav.classList.toggle('is-open', open);
            toggle.classList.toggle('is-open', open);
            toggle.setAttribute('aria-expanded', String(open));

            // پرده باید *قبل از* شروع انیمیشن نمایش داده شود
            if (open) backdrop.hidden = false;
            requestAnimationFrame(() =>
                backdrop.classList.toggle('is-visible', open)
            );

            // پس از پایان انیمیشن، پرده کاملاً از دسترس خارج شود
            if (!open) {
                setTimeout(() => {
                    if (!nav.classList.contains('is-open')) backdrop.hidden = true;
                }, 320);
            }

            lockScroll(open);
        }

        toggle.addEventListener('click', () =>
            setNav(!nav.classList.contains('is-open'))
        );

        // کلیک روی پرده → بستن منو
        backdrop.addEventListener('click', () => setNav(false));

        // کلیک روی هر لینک → بستن منو
        $$('a', nav).forEach((link) =>
            link.addEventListener('click', () => setNav(false))
        );

        // کلید Escape → بستن منو
        document.addEventListener('keydown', (ev) => {
            if (ev.key === 'Escape' && nav.classList.contains('is-open')) {
                setNav(false);
                toggle.focus();
            }
        });

        // اگر پنجره بزرگ شد (به دسکتاپ رفتیم)، منو باید بسته شود
        window.addEventListener('resize', () => {
            if (window.innerWidth > 900 && nav.classList.contains('is-open')) {
                setNav(false);
            }
        });
    })();


    /* ═══════════════════════════════════════════════════════
       ۲ · افکت اسکرول هدر + دکمهٔ بازگشت به بالا
       ═══════════════════════════════════════════════════════ */
    (function initScrollEffects() {
        const header  = $('#siteHeader');
        const toTop   = $('#backToTop');
        let   ticking = false;   // جلوگیری از اجرای بیش از حد تابع هنگام اسکرول

        function onScroll() {
            const y = window.scrollY;

            if (header) header.classList.toggle('is-scrolled', y > 10);

            if (toTop) {
                const show = y > 500;
                if (show) toTop.hidden = false;
                toTop.classList.toggle('is-visible', show);

                if (!show) {
                    setTimeout(() => {
                        if (!toTop.classList.contains('is-visible')) toTop.hidden = true;
                    }, 320);
                }
            }

            ticking = false;
        }

        // requestAnimationFrame → اجرای بهینه و روان هنگام اسکرول
        window.addEventListener(
            'scroll',
            () => {
                if (!ticking) {
                    ticking = true;
                    requestAnimationFrame(onScroll);
                }
            },
            { passive: true }
        );

        onScroll();   // اجرای اولیه

        if (toTop) {
            toTop.addEventListener('click', () =>
                window.scrollTo({
                    top: 0,
                    behavior: prefersReducedMotion ? 'auto' : 'smooth',
                })
            );
        }
    })();


    /* ═══════════════════════════════════════════════════════
       ۳ · پاپ‌آپ ثبت‌نام / ورود
       ═══════════════════════════════════════════════════════ */
    (function initAuthModal() {
        const modal = $('#authModal');
        if (!modal) return;   // این صفحه پاپ‌آپ ندارد

        const openBtns    = $$('[data-open-modal]');
        const closeBtns   = $$('[data-close-modal]', modal);
        const tabs        = $$('.modal-tab', modal);
        const switchLinks = $$('[data-switch-tab]', modal);
        const panels      = $$('[data-panel]', modal);
        const indicator   = $('#tabIndicator', modal);
        const tabsWrap    = $('.modal-tabs', modal);
        const title       = $('#modalTitle', modal);

        let lastFocused = null;   // عنصری که قبل از باز شدن پاپ‌آپ فوکوس داشت

        /* ── جابه‌جایی نشانگر زیر تب فعال ──
           از offset استفاده می‌کنیم تا transformِ والد در
           محاسبات اختلال ایجاد نکند.                        */
        function moveIndicator(tab) {
            if (!tab || !indicator || !tabsWrap) return;

            const wrapW = tabsWrap.clientWidth;
            const right = wrapW - (tab.offsetLeft + tab.offsetWidth);

            indicator.style.width = tab.offsetWidth + 'px';
            indicator.style.right = right + 'px';
        }

        /** فعال کردن یکی از تب‌ها (register یا login) */
        function activateTab(name) {
            tabs.forEach((t) => {
                const active = t.dataset.tab === name;
                t.classList.toggle('is-active', active);
                t.setAttribute('aria-selected', String(active));
                if (active) moveIndicator(t);
            });

            // hidden به‌جای style.display → معنایی‌تر و برای صفحه‌خوان بهتر است
            panels.forEach((p) => {
                p.hidden = p.dataset.panel !== name;
            });

            if (title) {
                title.textContent =
                    name === 'register' ? 'به آرِنا خوش آمدی' : 'دوباره خوش برگشتی';
            }
        }

        /* ── قفل فوکوس داخل پاپ‌آپ (Focus Trap) ──
           با Tab نمی‌توان از پاپ‌آپ خارج شد — الزام دسترس‌پذیری. */
        function trapFocus(ev) {
            if (ev.key !== 'Tab') return;

            const focusables = $$(
                'a[href], button:not([disabled]), input:not([disabled]), select, textarea',
                modal
            ).filter((el) => el.offsetParent !== null);   // فقط عناصر قابل مشاهده

            if (!focusables.length) return;

            const first = focusables[0];
            const last  = focusables[focusables.length - 1];

            if (ev.shiftKey && document.activeElement === first) {
                ev.preventDefault();
                last.focus();
            } else if (!ev.shiftKey && document.activeElement === last) {
                ev.preventDefault();
                first.focus();
            }
        }

        function openModal(tabName) {
            lastFocused = document.activeElement;

            modal.classList.add('is-open');
            modal.setAttribute('aria-hidden', 'false');
            lockScroll(true);

            if (tabName) activateTab(tabName);

            // فوکوس روی اولین فیلد، پس از پایان انیمیشن
            setTimeout(() => {
                const firstInput = $('[data-panel]:not([hidden]) input', modal);
                if (firstInput) firstInput.focus();
            }, 320);

            document.addEventListener('keydown', trapFocus);
        }

        function closeModal() {
            modal.classList.remove('is-open');
            modal.setAttribute('aria-hidden', 'true');
            lockScroll(false);

            document.removeEventListener('keydown', trapFocus);

            // بازگرداندن فوکوس به دکمه‌ای که پاپ‌آپ را باز کرده بود
            if (lastFocused) lastFocused.focus();
        }

        /* ── رویدادها ── */
        openBtns.forEach((btn) => {
            btn.addEventListener('click', (ev) => {
                ev.preventDefault();

                openModal(btn.dataset.openModal);

                // اگر کاربر از روی کارت یک رشته کلیک کرده،
                // همان رشته در فرم از پیش انتخاب شود
                const sportId = btn.dataset.sport;
                if (sportId) {
                    const select = $('select[name="favorite_sport"]', modal);
                    if (select) select.value = sportId;
                }
            });
        });

        closeBtns.forEach((btn) => btn.addEventListener('click', closeModal));

        // کلیک روی پس‌زمینهٔ تیره → بستن
        modal.addEventListener('click', (ev) => {
            if (ev.target === modal) closeModal();
        });

        // Escape → بستن
        document.addEventListener('keydown', (ev) => {
            if (ev.key === 'Escape' && modal.classList.contains('is-open')) {
                closeModal();
            }
        });

        tabs.forEach((tab) =>
            tab.addEventListener('click', () => activateTab(tab.dataset.tab))
        );

        switchLinks.forEach((link) =>
            link.addEventListener('click', (ev) => {
                ev.preventDefault();
                activateTab(link.dataset.switchTab);
            })
        );

        // موقعیت اولیهٔ نشانگر + به‌روزرسانی هنگام تغییر اندازهٔ پنجره
        requestAnimationFrame(() => {
            const active = $('.modal-tab.is-active', modal);
            if (active) moveIndicator(active);
        });

        window.addEventListener('resize', () => {
            const active = $('.modal-tab.is-active', modal);
            if (active) moveIndicator(active);
        });
    })();


    /* ═══════════════════════════════════════════════════════
       ۴ · ظاهر شدن تدریجی کارت‌ها هنگام اسکرول
       ═══════════════════════════════════════════════════════ */
    (function initScrollReveal() {
        const groups = $$('.reveal-group');
        if (!groups.length) return;

        // اگر کاربر «کاهش حرکت» را فعال کرده، همه‌چیز بدون انیمیشن نمایش داده شود
        if (prefersReducedMotion || !('IntersectionObserver' in window)) return;

        const items = [];

        // کلاس اولیه با جاوااسکریپت اضافه می‌شود؛
        // پس اگر JS غیرفعال باشد، محتوا همچنان دیده می‌شود.
        groups.forEach((group) => {
            Array.from(group.children).forEach((child, i) => {
                child.classList.add('reveal-item');
                // تأخیر پلکانی → کارت‌ها یکی‌یکی ظاهر می‌شوند
                child.style.transitionDelay = Math.min(i * 60, 400) + 'ms';
                items.push(child);
            });
        });

        const observer = new IntersectionObserver(
            (entries) => {
                entries.forEach((entry) => {
                    if (entry.isIntersecting) {
                        entry.target.classList.add('is-visible');
                        observer.unobserve(entry.target);   // فقط یک‌بار اجرا شود
                    }
                });
            },
            { threshold: 0.12, rootMargin: '0px 0px -40px 0px' }
        );

        items.forEach((item) => observer.observe(item));
    })();


    /* ═══════════════════════════════════════════════════════
       ۵ · انیمیشن شمارش اعداد آمار
       ═══════════════════════════════════════════════════════ */
    (function initCounters() {
        const counters = $$('[data-count]');
        if (!counters.length) return;

        /** شمارش از صفر تا مقدار نهایی */
        function runCount(el) {
            const target = parseInt(el.dataset.count, 10) || 0;

            // بدون انیمیشن در حالت «کاهش حرکت»
            if (prefersReducedMotion) {
                el.textContent = toFa(target) + '+';
                return;
            }

            const duration = 1400;
            const start    = performance.now();

            function tick(now) {
                const progress = Math.min((now - start) / duration, 1);

                // easeOutCubic → شروع سریع، پایان نرم
                const eased = 1 - Math.pow(1 - progress, 3);
                const value = Math.round(target * eased);

                el.textContent = toFa(value) + '+';

                if (progress < 1) requestAnimationFrame(tick);
            }

            requestAnimationFrame(tick);
        }

        // شمارش فقط وقتی شروع شود که عدد وارد دید کاربر شده باشد
        if (!('IntersectionObserver' in window)) {
            counters.forEach(runCount);
            return;
        }

        const observer = new IntersectionObserver(
            (entries) => {
                entries.forEach((entry) => {
                    if (entry.isIntersecting) {
                        runCount(entry.target);
                        observer.unobserve(entry.target);
                    }
                });
            },
            { threshold: 0.5 }
        );

        counters.forEach((el) => observer.observe(el));
    })();


    /* ═══════════════════════════════════════════════════════
       ۶ · ابزارهای فرم
       ═══════════════════════════════════════════════════════ */

    /* ── ۶.۱ · تبدیل خودکار ارقام فارسی به لاتین ── */
    $$('input[name="national_code"], input[name="age"]').forEach((input) => {
        input.addEventListener('input', () => {
            const converted = toEn(input.value);
            if (converted !== input.value) input.value = converted;
        });
    });

    /* ── ۶.۲ · محاسبهٔ خودکار سن از روی تاریخ تولد ── */
    $$('input[name="birth_date"]').forEach((birthInput) => {
        const form     = birthInput.closest('form');
        const ageInput = form && $('input[name="age"]', form);

        if (!ageInput) return;

        birthInput.addEventListener('change', () => {
            if (!birthInput.value) return;

            const today = new Date();
            const birth = new Date(birthInput.value);

            if (isNaN(birth.getTime())) return;

            let age = today.getFullYear() - birth.getFullYear();
            const monthDiff = today.getMonth() - birth.getMonth();

            // اگر هنوز تولدش در سال جاری نرسیده، یک سال کم می‌شود
            if (monthDiff < 0 || (monthDiff === 0 && today.getDate() < birth.getDate())) {
                age--;
            }

            if (age >= 0 && age <= 120) ageInput.value = age;
        });
    });

    /* ── ۶.۳ · نمایش / مخفی کردن رمز عبور ── */
    const EYE_OPEN =
        '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M2 12s3.5-7 10-7 10 7 10 7-3.5 7-10 7-10-7-10-7z"/><circle cx="12" cy="12" r="3"/></svg>';

    const EYE_OFF =
        '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M9.9 4.24A9.1 9.1 0 0 1 12 4c6.5 0 10 7 10 7a18 18 0 0 1-2.16 3.19M6.6 6.6A18 18 0 0 0 2 11s3.5 7 10 7a9 9 0 0 0 5.4-1.6"/><path d="m2 2 20 20"/></svg>';

    $$('[data-toggle-password]').forEach((btn) => {
        btn.innerHTML = EYE_OPEN;

        btn.addEventListener('click', () => {
            const input = $('input', btn.parentElement);
            if (!input) return;

            const isHidden = input.type === 'password';

            input.type    = isHidden ? 'text' : 'password';
            btn.innerHTML = isHidden ? EYE_OFF : EYE_OPEN;
            btn.setAttribute(
                'aria-label',
                isHidden ? 'مخفی کردن رمز عبور' : 'نمایش رمز عبور'
            );
        });
    });

    /* ── ۶.۴ · سنجش قدرت رمز عبور ── */
    $$('[data-password-meter]').forEach((meter) => {
        const group = meter.closest('.form-group');
        const input = group && $('input[type="password"]', group);

        if (!input) return;

        const bar   = $('.password-meter-text', meter);
        const LABEL = ['', 'ضعیف', 'متوسط', 'قوی'];

        input.addEventListener('input', () => {
            const val = input.value;

            // رمز خالی → نوار مخفی شود
            if (!val) {
                meter.hidden = true;
                return;
            }

            meter.hidden = false;

            /* امتیازدهی ساده:
               طول ≥۶ ، طول ≥۱۰ ، وجود حرف و عدد ، وجود نماد */
            let score = 0;
            if (val.length >= 6)                       score++;
            if (val.length >= 10)                      score++;
            if (/[a-zA-Z]/.test(val) && /\d/.test(val)) score++;
            if (/[^a-zA-Z0-9]/.test(val))              score++;

            // حداکثر سطح ۳
            const level = Math.min(score, 3);

            meter.dataset.level = String(level);
            if (bar) bar.textContent = 'قدرت رمز: ' + LABEL[level];
        });
    });

    /* ── ۶.۵ · بررسی تطابق رمز عبور با تکرار آن ── */
    $$('input[name="password_confirm"], input[name="new_password_confirm"]').forEach((confirm) => {
        const form = confirm.closest('form');
        const pairName = confirm.name === 'new_password_confirm' ? 'new_password' : 'password';
        const pass = form && $(`input[name="${pairName}"]`, form);

        if (!pass) return;

        // setCustomValidity → پیام خطای بومی مرورگر
        const check = () => {
            confirm.setCustomValidity(
                confirm.value && confirm.value !== pass.value
                    ? 'رمز عبور و تکرار آن یکسان نیستند'
                    : ''
            );
        };

        confirm.addEventListener('input', check);
        pass.addEventListener('input', check);
    });

    /* ── ۶.۶ب · تأیید قبل از ارسال فرم‌های حذف (پنل مدیریت) ── */
    $$('form[data-confirm]').forEach((form) => {
        form.addEventListener('submit', (ev) => {
            if (!window.confirm(form.dataset.confirm)) {
                ev.preventDefault();
                ev.stopImmediatePropagation();
            }
        });
    });

    /* ── ۶.۶ · جلوگیری از ارسال دوبارهٔ فرم ──
       با کلیک روی دکمه، دکمه غیرفعال می‌شود تا کاربر
       با دو بار کلیک، دو رکورد تکراری نسازد.               */
    $$('form').forEach((form) => {
        form.addEventListener('submit', () => {
            // اگر فرم نامعتبر است، دکمه را غیرفعال نکن
            if (!form.checkValidity()) return;

            const btn = $('button[type="submit"]', form);
            if (!btn) return;

            setTimeout(() => {
                btn.disabled = true;
                btn.style.opacity = '.7';
                btn.textContent = 'لطفاً صبر کنید…';
            }, 0);
        });
    });

})();
