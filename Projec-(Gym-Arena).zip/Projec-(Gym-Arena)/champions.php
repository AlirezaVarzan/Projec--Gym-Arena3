<?php
/**
 * ═══════════════════════════════════════════════════════════
 *  فهرست و جست‌وجوی قهرمانان
 *  همهٔ کاربران (حتی مهمان‌ها) می‌توانند این صفحه را ببینند و
 *  بر اساس رشته، کشور یا نام قهرمان فیلتر کنند.
 * ═══════════════════════════════════════════════════════════
 */
require_once __DIR__ . '/config.php';

$page_title = 'فهرست قهرمانان — آرِنا';

/* ─── خواندن فیلترها از URL (قابل بوکمارک و اشتراک‌گذاری) ─── */
$f_sport = isset($_GET['sport']) ? (int) $_GET['sport'] : 0;
$f_country = trim((string) ($_GET['country'] ?? ''));
$f_q     = trim((string) ($_GET['q'] ?? ''));

$sports    = $pdo->query("SELECT id, name, icon FROM sports ORDER BY id ASC")->fetchAll();
$countries = $pdo->query("SELECT DISTINCT country FROM champions ORDER BY country ASC")->fetchAll(PDO::FETCH_COLUMN);

/* ─── ساخت کوئری پویا بر اساس فیلترهای انتخاب‌شده ─── */
$where  = [];
$params = [];

if ($f_sport > 0) {
    $where[]  = 'c.sport_id = ?';
    $params[] = $f_sport;
}
if ($f_country !== '') {
    $where[]  = 'c.country = ?';
    $params[] = $f_country;
}
if ($f_q !== '') {
    $where[]  = '(c.name LIKE ? OR c.title LIKE ?)';
    $params[] = '%' . $f_q . '%';
    $params[] = '%' . $f_q . '%';
}

$sql = "
    SELECT c.id, c.name, c.title, c.bio, c.country, c.profileimg,
           s.name AS sport_name, s.icon AS sport_icon
    FROM champions c
    JOIN sports s ON c.sport_id = s.id
";
if ($where) {
    $sql .= ' WHERE ' . implode(' AND ', $where);
}
$sql .= ' ORDER BY c.id ASC';

$stmt = $pdo->prepare($sql);
$stmt->execute($params);
$champions = $stmt->fetchAll();

$total_found = count($champions);

include __DIR__ . '/header.php';
?>

<section class="page-hero">
    <div class="container">
        <div class="section-eyebrow">قهرمانان</div>
        <h1 class="section-title">با بزرگان رشتهٔ خودت آشنا شو</h1>
        <p class="section-subtitle">
            از میان <?= toPersianDigits(count($sports)) ?> رشتهٔ ورزشی و
            <?= toPersianDigits(count($countries)) ?> کشور، قهرمان الگوی خودت را پیدا کن.
        </p>
    </div>
</section>

<div class="container">

    <!-- ═══════════ نوار فیلتر جست‌وجو ═══════════ -->
    <form method="GET" class="club-filters">
        <div class="selector-field">
            <label for="f_sport">رشتهٔ ورزشی</label>
            <select id="f_sport" name="sport" class="form-control">
                <option value="0">همهٔ رشته‌ها</option>
                <?php foreach ($sports as $sp): ?>
                    <option value="<?= e($sp['id']) ?>" <?= $f_sport === (int) $sp['id'] ? 'selected' : '' ?>>
                        <?= e($sp['icon']) ?> <?= e($sp['name']) ?>
                    </option>
                <?php endforeach; ?>
            </select>
        </div>

        <div class="selector-field">
            <label for="f_country">کشور</label>
            <select id="f_country" name="country" class="form-control">
                <option value="">همهٔ کشورها</option>
                <?php foreach ($countries as $c): ?>
                    <option value="<?= e($c) ?>" <?= $f_country === $c ? 'selected' : '' ?>><?= e($c) ?></option>
                <?php endforeach; ?>
            </select>
        </div>

        <div class="selector-field selector-field-grow">
            <label for="f_q">جست‌وجوی نام یا لقب</label>
            <input type="text" id="f_q" name="q" class="form-control"
                   placeholder="مثلاً هادی چوپان، پلنگ مازندران…" value="<?= e($f_q) ?>">
        </div>

        <button type="submit" class="btn btn-primary">جست‌وجو</button>
        <?php if ($f_sport || $f_country || $f_q): ?>
            <a href="champions.php" class="btn btn-ghost">پاک کردن فیلترها</a>
        <?php endif; ?>
    </form>

    <div class="results-count">
        <?= toPersianDigits($total_found) ?> قهرمان پیدا شد
    </div>

    <!-- ═══════════ نتایج ═══════════ -->
    <?php if (!$champions): ?>
        <div class="empty-state">
            <span class="icon" aria-hidden="true">🔍</span>
            <p>هیچ قهرمانی با این فیلترها پیدا نشد.</p>
            <p class="hint">فیلترها را تغییر بده یا فیلتر کشور را حذف کن.</p>
        </div>
    <?php else: ?>
        <div class="champions-grid reveal-group">
            <?php foreach ($champions as $champ): ?>
                <a class="champion-card champion-card-link" href="champion.php?id=<?= e($champ['id']) ?>">
                    <div class="champion-avatar">
                        <?php if (!empty($champ['profileimg'])): ?>
                            <img src="<?= e($champ['profileimg']) ?>"
                                 alt="<?= e($champ['name']) ?>"
                                 loading="lazy" decoding="async">
                        <?php else: ?>
                            <span><?= e(initials($champ['name'])) ?></span>
                        <?php endif; ?>
                    </div>

                    <h3 class="champion-name"><?= e($champ['name']) ?></h3>

                    <?php if (!empty($champ['title'])): ?>
                        <div class="champion-title"><?= e($champ['title']) ?></div>
                    <?php endif; ?>

                    <p class="champion-bio"><?= e($champ['bio']) ?></p>

                    <span class="champion-country">
                        <?= e($champ['sport_icon']) ?>
                        <?= e($champ['sport_name']) ?> · <?= e($champ['country']) ?>
                    </span>
                </a>
            <?php endforeach; ?>
        </div>
    <?php endif; ?>

</div>

<?php include __DIR__ . '/footer.php'; ?>
