<?php
/**
 * ═══════════════════════════════════════════════════════════
 *  پردازش فرم ورود
 * ═══════════════════════════════════════════════════════════
 */
require_once __DIR__ . '/config.php';

// این فایل فقط با متد POST قابل دسترسی است
if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    redirect('signup.php');
}

// بررسی توکن CSRF — جلوگیری از ارسال فرم از سایت‌های دیگر
verifyCsrf();

$username = trim($_POST['username'] ?? '');
$password = $_POST['password'] ?? '';

// نگه‌داشتن نام کاربری تا در صورت خطا دوباره در فرم نمایش داده شود
flash('old', ['username' => $username]);

/* ─── اعتبارسنجی اولیه ───────────────────────────────────── */
if ($username === '' || $password === '') {
    flash('error', 'نام کاربری و رمز عبور الزامی است.');
    redirect('signup.php');
}

/* ─── جست‌وجوی کاربر در دیتابیس ──────────────────────────── */
$stmt = $pdo->prepare("SELECT id, username, password, is_admin FROM users WHERE username = ? LIMIT 1");
$stmt->execute([$username]);
$user = $stmt->fetch();

/* ─── بررسی صحت رمز عبور ─────────────────────────────────
   نکتهٔ امنیتی: پیام خطا برای «کاربر ناموجود» و «رمز اشتباه»
   یکسان است تا مهاجم نتواند وجود یک نام کاربری را حدس بزند.  */
if (!$user || !password_verify($password, $user['password'])) {
    flash('error', 'نام کاربری یا رمز عبور اشتباه است.');
    redirect('signup.php');
}

/* ─── ورود موفق ─────────────────────────────────────────── */

// تولید شناسهٔ جدید برای سشن → جلوگیری از حملهٔ Session Fixation
session_regenerate_id(true);

$_SESSION['user_id']  = (int) $user['id'];
$_SESSION['username'] = $user['username'];
$_SESSION['is_admin'] = (bool) ($user['is_admin'] ?? false);

// اگر الگوریتم هش رمز قدیمی شده بود، آن را با الگوریتم روز به‌روزرسانی کن
if (password_needs_rehash($user['password'], PASSWORD_DEFAULT)) {
    $newHash = password_hash($password, PASSWORD_DEFAULT);
    $pdo->prepare("UPDATE users SET password = ? WHERE id = ?")
        ->execute([$newHash, $user['id']]);
}

// پاک کردن پیام‌های موقتی باقی‌مانده
unset($_SESSION['flash']);

redirect('dashboard.php');
