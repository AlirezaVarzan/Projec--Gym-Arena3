<?php
/**
 * ═══════════════════════════════════════════════════════════
 *  کامپوننت پاپ‌آپ (Modal) ثبت‌نام و ورود
 *  پیش‌نیاز: متغیر $sports باید از قبل تعریف شده باشد.
 * ═══════════════════════════════════════════════════════════
 */
$_sports = $sports ?? [];
?>

<div class="modal-overlay" id="authModal" aria-hidden="true">
    <div class="modal" role="dialog" aria-modal="true" aria-labelledby="modalTitle">

        <button type="button" class="modal-close" aria-label="بستن پنجره" data-close-modal>
            <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" aria-hidden="true">
                <path d="M18 6 6 18M6 6l12 12"/>
            </svg>
        </button>

        <div class="modal-header">
            <h2 id="modalTitle">به آرِنا خوش آمدی</h2>
            <p>به جمع ورزشکاران کشور بپیوند</p>
        </div>

        <!-- تب‌های جابه‌جایی بین ثبت‌نام و ورود -->
        <div class="modal-tabs" role="tablist">
            <button type="button" class="modal-tab is-active" data-tab="register"
                    role="tab" aria-selected="true">ثبت نام</button>
            <button type="button" class="modal-tab" data-tab="login"
                    role="tab" aria-selected="false">ورود</button>
            <!-- نشانگر متحرکی که زیر تب فعال حرکت می‌کند -->
            <span class="modal-tab-indicator" id="tabIndicator" aria-hidden="true"></span>
        </div>

        <div class="modal-body">

            <!-- ─────── فرم ثبت‌نام ─────── -->
            <form class="auth-form" data-panel="register"
                  action="process_register.php" method="POST" novalidate>

                <?= csrfField() /* توکن ضد CSRF */ ?>

                <div class="form-row">
                    <div class="form-group">
                        <label class="form-label" for="m_full_name">نام و نام خانوادگی</label>
                        <input type="text" id="m_full_name" name="full_name" class="form-control"
                               placeholder="مثلاً پوریا ابراهیمی" autocomplete="name" required>
                    </div>
                    <div class="form-group">
                        <label class="form-label" for="m_national_code">کد ملی</label>
                        <input type="text" id="m_national_code" name="national_code" class="form-control"
                               placeholder="۱۰ رقمی" maxlength="10" inputmode="numeric" required>
                    </div>
                </div>

                <div class="form-row">
                    <div class="form-group">
                        <label class="form-label" for="m_birth_date">تاریخ تولد</label>
                        <input type="date" id="m_birth_date" name="birth_date" class="form-control"
                               autocomplete="bday" required>
                    </div>
                    <div class="form-group">
                        <label class="form-label" for="m_age">سن</label>
                        <!-- این فیلد از روی تاریخ تولد به‌صورت خودکار پر می‌شود -->
                        <input type="number" id="m_age" name="age" class="form-control"
                               placeholder="خودکار" min="6" max="100" required>
                    </div>
                </div>

                <div class="form-row">
                    <div class="form-group">
                        <label class="form-label" for="m_sport">رشتهٔ ورزشی مورد علاقه</label>
                        <select id="m_sport" name="favorite_sport" class="form-control" required>
                            <option value="">انتخاب کن…</option>
                            <?php foreach ($_sports as $sp): ?>
                                <option value="<?= e($sp['id']) ?>">
                                    <?= e($sp['icon']) ?> <?= e($sp['name']) ?>
                                </option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                    <div class="form-group">
                        <label class="form-label" for="m_city">نام شهر</label>
                        <input type="text" id="m_city" name="city" class="form-control"
                               placeholder="مثلاً شیراز" autocomplete="address-level2" required>
                    </div>
                </div>

                <div class="form-group">
                    <label class="form-label" for="m_username">نام کاربری</label>
                    <input type="text" id="m_username" name="username" class="form-control"
                           placeholder="انگلیسی، حداقل ۴ کاراکتر" minlength="4"
                           autocomplete="username" required>
                </div>

                <div class="form-row">
                    <div class="form-group">
                        <label class="form-label" for="m_password">رمز عبور</label>
                        <!-- .password-wrap → دکمهٔ نمایش/مخفی‌کردن رمز کنار فیلد قرار می‌گیرد -->
                        <div class="password-wrap">
                            <input type="password" id="m_password" name="password" class="form-control"
                                   placeholder="حداقل ۶ کاراکتر" minlength="6"
                                   autocomplete="new-password" required>
                            <button type="button" class="password-toggle" data-toggle-password
                                    aria-label="نمایش رمز عبور"></button>
                        </div>
                        <!-- نوار سنجش قدرت رمز عبور (توسط app.js پر می‌شود) -->
                        <div class="password-meter" data-password-meter hidden>
                            <div class="password-meter-bar"><span></span></div>
                            <small class="password-meter-text"></small>
                        </div>
                    </div>
                    <div class="form-group">
                        <label class="form-label" for="m_password2">تکرار رمز عبور</label>
                        <div class="password-wrap">
                            <input type="password" id="m_password2" name="password_confirm" class="form-control"
                                   placeholder="مجدداً وارد کن" minlength="6"
                                   autocomplete="new-password" required>
                            <button type="button" class="password-toggle" data-toggle-password
                                    aria-label="نمایش رمز عبور"></button>
                        </div>
                    </div>
                </div>

                <button type="submit" class="btn btn-primary btn-block btn-lg">
                    ساخت حساب کاربری
                </button>

                <div class="form-footer">
                    حساب داری؟ <a href="#" data-switch-tab="login">وارد شو</a>
                </div>
            </form>

            <!-- ─────── فرم ورود ─────── -->
            <form class="auth-form" data-panel="login" hidden
                  action="process_login.php" method="POST" novalidate>

                <?= csrfField() ?>

                <div class="form-group">
                    <label class="form-label" for="m_l_username">نام کاربری</label>
                    <input type="text" id="m_l_username" name="username" class="form-control"
                           placeholder="نام کاربری خود را وارد کن" autocomplete="username" required>
                </div>

                <div class="form-group">
                    <label class="form-label" for="m_l_password">رمز عبور</label>
                    <div class="password-wrap">
                        <input type="password" id="m_l_password" name="password" class="form-control"
                               placeholder="رمز عبور" autocomplete="current-password" required>
                        <button type="button" class="password-toggle" data-toggle-password
                                aria-label="نمایش رمز عبور"></button>
                    </div>
                </div>

                <button type="submit" class="btn btn-primary btn-block btn-lg">
                    ورود به آرِنا
                </button>

                <div class="form-footer">
                    هنوز عضو نشدی؟ <a href="#" data-switch-tab="register">ثبت نام کن</a>
                </div>
            </form>

        </div>
    </div>
</div>
