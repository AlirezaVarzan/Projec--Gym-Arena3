<?php
/**
 * ═══════════════════════════════════════════════════════════
 *  هدر مشترک تمام صفحات
 *  شامل: تگ‌های <head> ، نوار ناوبری دسکتاپ و منوی موبایل
 * ═══════════════════════════════════════════════════════════
 */
require_once __DIR__ . '/config.php';

// عنوان صفحه؛ اگر صفحه‌ای مقدار خاصی تعریف نکرده باشد از پیش‌فرض استفاده می‌شود
$page_title = $page_title ?? 'آرِنا — پلتفرم ورزشکاران ایران';

// نام فایل صفحهٔ فعلی — برای هایلایت کردن لینک فعال در منو
$current_page = basename($_SERVER['PHP_SELF']);
?>
<!DOCTYPE html>
<html lang="fa" dir="rtl">
<head>
    <meta charset="UTF-8">
    <!-- viewport → پایهٔ ریسپانسیو بودن سایت روی موبایل -->
    <meta name="viewport" content="width=device-width, initial-scale=1, viewport-fit=cover">
    <meta name="description" content="آرِنا — پلتفرم ورزشکاران ایران. با قهرمانان رشتهٔ ورزشی خود آشنا شوید و باشگاه‌های فعال شهرتان را پیدا کنید.">
    <meta name="theme-color" content="#0a0b10">

    <title><?= e($page_title) ?></title>

    <!-- پیش‌بارگذاری فونت وزیر → جلوگیری از پرش متن هنگام لود (FOUT) -->
    <link rel="preload" href="Vazir.woff2" as="font" type="font/woff2" crossorigin>

    <!-- فایل استایل اصلی؛ پارامتر نسخه برای شکستن کش مرورگر هنگام تغییر -->
    <link rel="stylesheet" href="style.css?v=3.0">
</head>
<body>

<!-- لینک پرش به محتوا — برای دسترس‌پذیری و کاربران صفحه‌خوان -->
<a href="#main" class="skip-link">رفتن به محتوای اصلی</a>

<header class="site-header" id="siteHeader">
    <div class="container header-inner">

        <!-- لوگو -->
        <a href="index.php" class="logo" aria-label="آرِنا — صفحهٔ اصلی">
            <span class="logo-mark" aria-hidden="true">آ</span>
            <span class="logo-text">آرِنا<span class="accent">.</span></span>
        </a>

        <!-- ناوبری اصلی (در موبایل به‌صورت کشویی نمایش داده می‌شود) -->
        <nav class="main-nav" id="mainNav" aria-label="ناوبری اصلی">
            <a href="index.php" <?= $current_page === 'index.php' ? 'class="is-active"' : '' ?>>خانه</a>
            <a href="index.php#sports">رشته‌ها</a>
            <a href="champions.php" <?= ($current_page === 'champions.php' || $current_page === 'champion.php') ? 'class="is-active"' : '' ?>>قهرمانان</a>
            <a href="clubs.php" <?= ($current_page === 'clubs.php' || $current_page === 'club.php') ? 'class="is-active"' : '' ?>>باشگاه‌ها</a>
            <?php if (isLoggedIn()): ?>
                <a href="dashboard.php" <?= $current_page === 'dashboard.php' ? 'class="is-active"' : '' ?>>داشبورد</a>
                <a href="profile.php" <?= $current_page === 'profile.php' ? 'class="is-active"' : '' ?>>حساب من</a>
                <?php if (isAdmin()): ?>
                    <a href="admin/index.php">پنل مدیریت</a>
                <?php endif; ?>
            <?php endif; ?>

            <!-- دکمه‌های ورود/خروج — فقط داخل منوی موبایل دیده می‌شوند -->
            <div class="nav-cta-mobile">
                <?php if (isLoggedIn()): ?>
                    <a href="logout.php" class="btn btn-primary btn-block">خروج از حساب</a>
                <?php else: ?>
                    <a href="signup.php" class="btn btn-ghost btn-block">ورود</a>
                    <a href="register.php" class="btn btn-primary btn-block">ثبت نام</a>
                <?php endif; ?>
            </div>
        </nav>

        <!-- دکمه‌های اقدام در دسکتاپ -->
        <div class="header-cta">
            <?php if (isLoggedIn()): ?>
                <a href="dashboard.php" class="btn btn-ghost btn-sm">داشبورد</a>
                <a href="logout.php" class="btn btn-primary btn-sm">خروج</a>
            <?php else: ?>
                <a href="signup.php" class="btn btn-ghost btn-sm">ورود</a>
                <a href="register.php" class="btn btn-primary btn-sm">ثبت نام</a>
            <?php endif; ?>
        </div>

        <!-- دکمهٔ همبرگری — فقط در موبایل نمایش داده می‌شود -->
        <button type="button" class="nav-toggle" id="navToggle"
                aria-label="باز و بسته کردن منو" aria-expanded="false" aria-controls="mainNav">
            <span class="nav-toggle-bar"></span>
            <span class="nav-toggle-bar"></span>
            <span class="nav-toggle-bar"></span>
        </button>

    </div>
</header>

<!-- پرده‌ی تیرهٔ پشت منوی موبایل -->
<div class="nav-backdrop" id="navBackdrop" hidden></div>

<main id="main">
