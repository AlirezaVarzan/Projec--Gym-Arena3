<?php
/**
 * ═══════════════════════════════════════════════════════════
 *  صفحهٔ ورود
 *  توجه: نام این فایل طبق ساختار اصلی پروژهٔ شما «signup.php»
 *  باقی مانده تا لینک‌های قبلی نشکنند، ولی محتوای آن فرم
 *  «ورود» است.
 * ═══════════════════════════════════════════════════════════
 */
require_once __DIR__ . '/config.php';

if (isLoggedIn()) {
    redirect('dashboard.php');
}

$page_title = 'ورود به آرِنا';

$error   = flash('error');
$success = flash('success');
$old     = flash('old') ?: [];

include __DIR__ . '/header.php';
?>

<section class="auth-page">
    <div class="auth-card">

        <div class="auth-header">
            <span class="auth-badge">خوش برگشتی</span>
            <h1>ورود به آرِنا</h1>
            <p class="subtitle">به جمع ورزشکاران ایران برگرد</p>
        </div>

        <?php if ($error): ?>
            <div class="form-message error" role="alert">
                <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" aria-hidden="true">
                    <circle cx="12" cy="12" r="10"/><path d="M12 8v4M12 16h.01"/>
                </svg>
                <span><?= e($error) ?></span>
            </div>
        <?php endif; ?>

        <?php if ($success): ?>
            <div class="form-message success" role="status">
                <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" aria-hidden="true">
                    <path d="M20 6 9 17l-5-5"/>
                </svg>
                <span><?= e($success) ?></span>
            </div>
        <?php endif; ?>

        <form action="process_login.php" method="POST" novalidate>
            <?= csrfField() ?>

            <div class="form-group">
                <label class="form-label" for="username">نام کاربری</label>
                <input type="text" id="username" name="username" class="form-control"
                       placeholder="نام کاربری خود را وارد کن" autocomplete="username"
                       value="<?= e($old['username'] ?? '') ?>" required autofocus>
            </div>

            <div class="form-group">
                <label class="form-label" for="password">رمز عبور</label>
                <div class="password-wrap">
                    <input type="password" id="password" name="password" class="form-control"
                           placeholder="رمز عبور" autocomplete="current-password" required>
                    <button type="button" class="password-toggle" data-toggle-password
                            aria-label="نمایش رمز عبور"></button>
                </div>
            </div>

            <button type="submit" class="btn btn-primary btn-block btn-lg">
                ورود
            </button>

            <div class="form-footer">
                هنوز عضو نشدی؟ <a href="register.php">ثبت نام کن</a>
            </div>
        </form>
    </div>
</section>

<?php include __DIR__ . '/footer.php'; ?>
