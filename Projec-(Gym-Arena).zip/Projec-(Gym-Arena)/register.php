<?php
/**
 * ═══════════════════════════════════════════════════════════
 *  صفحهٔ ثبت‌نام (نسخهٔ کامل، خارج از پاپ‌آپ)
 * ═══════════════════════════════════════════════════════════
 */
require_once __DIR__ . '/config.php';

if (isLoggedIn()) {
    redirect('dashboard.php');
}

$page_title = 'ثبت نام در آرِنا';

// فهرست رشته‌های ورزشی برای منوی کشویی
$sports = $pdo->query("SELECT id, name, icon FROM sports ORDER BY id ASC")->fetchAll();

// پیام خطا و مقادیر قبلی فرم (در صورت بازگشت از پردازش ناموفق)
$error = flash('error');
$old   = flash('old') ?: [];

include __DIR__ . '/header.php';
?>

<section class="auth-page">
    <div class="auth-card auth-card-wide">

        <div class="auth-header">
            <span class="auth-badge">عضویت</span>
            <h1>به آرِنا بپیوند</h1>
            <p class="subtitle">حساب کاربری ورزشکاری خود را بساز</p>
        </div>

        <?php if ($error): ?>
            <div class="form-message error" role="alert">
                <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" aria-hidden="true">
                    <circle cx="12" cy="12" r="10"/><path d="M12 8v4M12 16h.01"/>
                </svg>
                <span><?= e($error) ?></span>
            </div>
        <?php endif; ?>

        <form action="process_register.php" method="POST" novalidate>
            <?= csrfField() ?>

            <div class="form-row">
                <div class="form-group">
                    <label class="form-label" for="full_name">نام و نام خانوادگی</label>
                    <input type="text" id="full_name" name="full_name" class="form-control"
                           placeholder="مثلاً علیرضا ورزن" autocomplete="name"
                           value="<?= e($old['full_name'] ?? '') ?>" required>
                </div>
                <div class="form-group">
                    <label class="form-label" for="national_code">کد ملی</label>
                    <input type="text" id="national_code" name="national_code" class="form-control"
                           placeholder="۱۰ رقمی" maxlength="10" inputmode="numeric"
                           value="<?= e($old['national_code'] ?? '') ?>" required>
                </div>
            </div>

            <div class="form-row">
                <div class="form-group">
                    <label class="form-label" for="birth_date">تاریخ تولد</label>
                    <input type="date" id="birth_date" name="birth_date" class="form-control"
                           autocomplete="bday"
                           value="<?= e($old['birth_date'] ?? '') ?>" required>
                </div>
                <div class="form-group">
                    <label class="form-label" for="age">سن</label>
                    <!-- به‌صورت خودکار از تاریخ تولد محاسبه می‌شود -->
                    <input type="number" id="age" name="age" class="form-control"
                           placeholder="خودکار" min="6" max="100"
                           value="<?= e($old['age'] ?? '') ?>" required>
                </div>
            </div>

            <div class="form-row">
                <div class="form-group">
                    <label class="form-label" for="favorite_sport">رشتهٔ ورزشی مورد علاقه</label>
                    <select id="favorite_sport" name="favorite_sport" class="form-control" required>
                        <option value="">انتخاب کن…</option>
                        <?php foreach ($sports as $sp): ?>
                            <option value="<?= e($sp['id']) ?>"
                                <?= (($old['favorite_sport'] ?? '') == $sp['id']) ? 'selected' : '' ?>>
                                <?= e($sp['icon']) ?> <?= e($sp['name']) ?>
                            </option>
                        <?php endforeach; ?>
                    </select>
                </div>
                <div class="form-group">
                    <label class="form-label" for="city">نام شهر</label>
                    <input type="text" id="city" name="city" class="form-control"
                           placeholder="مثلاً شیراز" autocomplete="address-level2"
                           value="<?= e($old['city'] ?? '') ?>" required>
                </div>
            </div>

            <div class="form-group">
                <label class="form-label" for="username">نام کاربری</label>
                <input type="text" id="username" name="username" class="form-control"
                       placeholder="انگلیسی، حداقل ۴ کاراکتر" minlength="4"
                       autocomplete="username"
                       value="<?= e($old['username'] ?? '') ?>" required>
            </div>

            <div class="form-row">
                <div class="form-group">
                    <label class="form-label" for="password">رمز عبور</label>
                    <div class="password-wrap">
                        <input type="password" id="password" name="password" class="form-control"
                               placeholder="حداقل ۶ کاراکتر" minlength="6"
                               autocomplete="new-password" required>
                        <button type="button" class="password-toggle" data-toggle-password
                                aria-label="نمایش رمز عبور"></button>
                    </div>
                    <div class="password-meter" data-password-meter hidden>
                        <div class="password-meter-bar"><span></span></div>
                        <small class="password-meter-text"></small>
                    </div>
                </div>
                <div class="form-group">
                    <label class="form-label" for="password_confirm">تکرار رمز عبور</label>
                    <div class="password-wrap">
                        <input type="password" id="password_confirm" name="password_confirm" class="form-control"
                               placeholder="مجدداً وارد کن" minlength="6"
                               autocomplete="new-password" required>
                        <button type="button" class="password-toggle" data-toggle-password
                                aria-label="نمایش رمز عبور"></button>
                    </div>
                </div>
            </div>

            <button type="submit" class="btn btn-primary btn-block btn-lg">
                ساخت حساب کاربری
            </button>

            <div class="form-footer">
                قبلاً ثبت‌نام کردی؟ <a href="signup.php">وارد شو</a>
            </div>
        </form>
    </div>
</section>

<?php include __DIR__ . '/footer.php'; ?>
