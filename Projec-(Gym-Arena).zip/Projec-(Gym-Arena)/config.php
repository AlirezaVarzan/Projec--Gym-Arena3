<?php
/**
 * ═══════════════════════════════════════════════════════════
 *  آرِنا — فایل پیکربندی مرکزی
 * ───────────────────────────────────────────────────────────
 *  تنها نقطهٔ ورود تنظیمات پروژه:
 *   • اتصال امن به دیتابیس با PDO
 *   • راه‌اندازی سشن با کوکی امن (HttpOnly / SameSite)
 *   • توابع کمکی: e() ، flash() ، csrf() و …
 * ═══════════════════════════════════════════════════════════
 */

declare(strict_types=1);

/* ─── حالت توسعه ───────────────────────────────────────────
   در محیط واقعی (production) این مقدار را false کنید تا
   جزئیات خطا به کاربر نهایی نشان داده نشود.                  */
const APP_DEBUG = true;

if (APP_DEBUG) {
    error_reporting(E_ALL);
    ini_set('display_errors', '1');
} else {
    error_reporting(0);
    ini_set('display_errors', '0');
}

/* ─── تنظیمات اتصال به دیتابیس ─────────────────────────────
   این مقادیر را با اطلاعات سرور خودتان جایگزین کنید.        */
const DB_HOST    = 'localhost';
const DB_NAME    = 'arena_athletes';
const DB_USER    = 'root';
const DB_PASS    = '';
const DB_CHARSET = 'utf8mb4';

/* ═══════════════════════════════════════════════════════════
   بخش ۱ — راه‌اندازی امن سشن
   ═══════════════════════════════════════════════════════════ */
if (session_status() === PHP_SESSION_NONE) {

    // آیا سایت روی HTTPS اجرا می‌شود؟
    $isHttps = (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off')
        || (($_SERVER['SERVER_PORT'] ?? null) == 443);

    // پارامترهای کوکی سشن برای جلوگیری از سرقت سشن
    session_set_cookie_params([
        'lifetime' => 0,        // با بستن مرورگر پاک شود
        'path'     => '/',
        'httponly' => true,     // جاوااسکریپت به کوکی دسترسی نداشته باشد (ضد XSS)
        'secure'   => $isHttps, // فقط روی HTTPS ارسال شود
        'samesite' => 'Lax',    // محافظت پایه در برابر CSRF
    ]);

    session_name('ARENA_SESSID');
    session_start();
}

/* ═══════════════════════════════════════════════════════════
   بخش ۲ — اتصال به دیتابیس (PDO)
   ═══════════════════════════════════════════════════════════ */
try {
    $dsn = sprintf('mysql:host=%s;dbname=%s;charset=%s', DB_HOST, DB_NAME, DB_CHARSET);

    /** @var PDO $pdo شیء اتصال سراسری به دیتابیس */
    $pdo = new PDO($dsn, DB_USER, DB_PASS, [
        // خطاهای دیتابیس به‌صورت Exception پرتاب شوند تا بی‌صدا رد نشوند
        PDO::ATTR_ERRMODE            => PDO::ERRMODE_EXCEPTION,
        // نتایج به‌صورت آرایهٔ انجمنی برگردند (نام ستون => مقدار)
        PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
        // Prepared Statement واقعی → امنیت کامل در برابر SQL Injection
        PDO::ATTR_EMULATE_PREPARES   => false,
    ]);

} catch (PDOException $e) {
    http_response_code(500);
    $msg = APP_DEBUG
        ? 'خطا در اتصال به دیتابیس: ' . $e->getMessage()
        : 'در حال حاضر امکان اتصال به سرور وجود ندارد. لطفاً بعداً تلاش کنید.';
    exit('<div style="font-family:sans-serif;direction:rtl;padding:40px;text-align:center">'
        . htmlspecialchars($msg, ENT_QUOTES, 'UTF-8') . '</div>');
}

/* ═══════════════════════════════════════════════════════════
   بخش ۳ — توابع کمکی
   ═══════════════════════════════════════════════════════════ */

/**
 * امن‌سازی خروجی (Escape) برای جلوگیری از حملات XSS.
 * هر مقداری که در HTML چاپ می‌شود باید از این تابع عبور کند.
 */
function e(mixed $value): string
{
    return htmlspecialchars((string) ($value ?? ''), ENT_QUOTES | ENT_SUBSTITUTE, 'UTF-8');
}

/** بررسی می‌کند که آیا کاربر وارد حساب خود شده است یا نه. */
function isLoggedIn(): bool
{
    return isset($_SESSION['user_id']);
}

/**
 * پیشوند نسبی تا ریشهٔ سایت — لازم چون بعضی صفحات (مثل پنل مدیریت)
 * داخل زیرپوشهٔ admin/ قرار دارند و مسیرهای نسبی «index.php» یا
 * «dashboard.php» از آن‌جا به آدرس اشتباه (مثلاً admin/dashboard.php)
 * حل می‌شوند. این تابع بر اساس مسیر اسکریپت جاری، پیشوند درست را
 * برمی‌گرداند تا redirect() همیشه به ریشهٔ سایت اشاره کند.
 */
function siteRoot(): string
{
    return basename(dirname($_SERVER['SCRIPT_NAME'])) === 'admin' ? '../' : '';
}

/** اجبار به ورود؛ در صورت عدم ورود، کاربر به صفحهٔ اصلی هدایت می‌شود. */
function requireLogin(): void
{
    if (!isLoggedIn()) {
        redirect(siteRoot() . 'index.php');
    }
}

/** بررسی می‌کند که آیا کاربر جاری دسترسی مدیریت (ادمین) دارد یا نه. */
function isAdmin(): bool
{
    return isLoggedIn() && !empty($_SESSION['is_admin']);
}

/** اجبار به داشتن دسترسی ادمین؛ در غیر این صورت کاربر به داشبورد هدایت می‌شود. */
function requireAdmin(): void
{
    requireLogin();
    if (!isAdmin()) {
        flash('error', 'شما دسترسی لازم برای این بخش را ندارید.');
        redirect(siteRoot() . 'dashboard.php');
    }
}

/** هدایت امن به یک آدرس و پایان اجرای اسکریپت. */
function redirect(string $path): never
{
    header('Location: ' . $path, true, 302);
    exit;
}

/**
 * مدیریت پیام‌های فلش (پیام‌های یک‌بارمصرف بین دو درخواست).
 *   • نوشتن:  flash('error', 'پیام خطا');
 *   • خواندن: $err = flash('error');   ← پس از خواندن پاک می‌شود
 */
function flash(string $key, mixed $value = null): mixed
{
    if ($value === null) {
        $val = $_SESSION['flash'][$key] ?? null;
        unset($_SESSION['flash'][$key]);
        return $val;
    }

    $_SESSION['flash'][$key] = $value;
    return null;
}

/* ─── محافظت در برابر CSRF ─────────────────────────────────
   هر فرم POST باید یک توکن مخفی همراه داشته باشد تا مطمئن
   شویم درخواست واقعاً از خودِ سایت ما ارسال شده است.          */

/** توکن CSRF جاری را برمی‌گرداند (و در صورت نبود، می‌سازد). */
function csrfToken(): string
{
    if (empty($_SESSION['csrf_token'])) {
        $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
    }
    return $_SESSION['csrf_token'];
}

/** فیلد مخفی CSRF را برای درج مستقیم داخل فرم برمی‌گرداند. */
function csrfField(): string
{
    return '<input type="hidden" name="_token" value="' . e(csrfToken()) . '">';
}

/**
 * صحت توکن CSRF ارسالی را بررسی می‌کند.
 * در صورت نامعتبر بودن، اجرای برنامه متوقف می‌شود.
 */
function verifyCsrf(): void
{
    $sent = $_POST['_token'] ?? '';

    // hash_equals از حملات زمانی (Timing Attack) جلوگیری می‌کند
    if (!is_string($sent) || !hash_equals($_SESSION['csrf_token'] ?? '', $sent)) {
        http_response_code(419);
        exit('درخواست نامعتبر است. لطفاً صفحه را تازه‌سازی کرده و دوباره تلاش کنید.');
    }
}

/* ─── ابزارهای کار با اعداد فارسی ─────────────────────────── */

/** تبدیل ارقام فارسی/عربی به لاتین (۰۹ → 09) — برای اعتبارسنجی. */
function toEnglishDigits(string $str): string
{
    $persian = ['۰','۱','۲','۳','۴','۵','۶','۷','۸','۹'];
    $arabic  = ['٠','١','٢','٣','٤','٥','٦','٧','٨','٩'];
    $english = ['0','1','2','3','4','5','6','7','8','9'];

    return str_replace($persian, $english, str_replace($arabic, $english, $str));
}

/** تبدیل ارقام لاتین به فارسی — فقط برای نمایش زیباتر در رابط کاربری. */
function toPersianDigits(string|int $value): string
{
    $english = ['0','1','2','3','4','5','6','7','8','9'];
    $persian = ['۰','۱','۲','۳','۴','۵','۶','۷','۸','۹'];

    return str_replace($english, $persian, (string) $value);
}

/* ─── سازگاری با هاست‌های بدون افزونهٔ mbstring ────────────
   برخی هاست‌های اشتراکی افزونهٔ mbstring را فعال ندارند.
   این توابع جایگزین، از خطای کشندهٔ «undefined function»
   جلوگیری می‌کنند و متن فارسی را درست پردازش می‌کنند.       */

if (!function_exists('mb_substr')) {
    /** جایگزین mb_substr با استفاده از الگوی یونیکد */
    function mb_substr(string $s, int $start, ?int $len = null, ?string $enc = null): string
    {
        $chars = preg_split('//u', $s, -1, PREG_SPLIT_NO_EMPTY) ?: [];
        $slice = array_slice($chars, $start, $len);
        return implode('', $slice);
    }
}

if (!function_exists('mb_strlen')) {
    /** جایگزین mb_strlen — شمارش «کاراکتر» به‌جای «بایت» */
    function mb_strlen(string $s, ?string $enc = null): int
    {
        return count(preg_split('//u', $s, -1, PREG_SPLIT_NO_EMPTY) ?: []);
    }
}

/**
 * تولید حرف اول نام برای آواتار پیش‌فرض (وقتی عکس قهرمان موجود نیست).
 */
function initials(string $name): string
{
    return mb_substr(trim($name), 0, 1, 'UTF-8');
}
