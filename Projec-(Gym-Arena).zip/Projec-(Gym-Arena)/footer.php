</main>

<footer class="site-footer">
    <div class="container">
        <div class="footer-inner">

            <!-- معرفی برند -->
            <div class="footer-brand">
                <div class="footer-logo">
                    <span class="logo-mark" aria-hidden="true">آ</span>
                    <span class="logo-text">آرِنا<span class="accent">.</span></span>
                </div>
                <p>محلی برای ورزشکاران سراسر ایران تا با بزرگان رشتهٔ خود و باشگاه‌های شهرشان آشنا شوند.</p>
            </div>

            <!-- دسترسی سریع -->
            <nav class="footer-nav" aria-label="دسترسی سریع">
                <h4>دسترسی سریع</h4>
                <a href="index.php">خانه</a>
                <a href="clubs.php">باشگاه‌ها</a>
                <a href="register.php">ثبت نام</a>
                <a href="signup.php">ورود</a>
                <a href="index.php#sports">رشته‌های ورزشی</a>
            </nav>

            <!-- دربارهٔ ما -->
            <div class="footer-info">
                <h4>دربارهٔ آرِنا</h4>
                <p>با آرِنا با قهرمانان رشته‌ای که عاشقش هستید آشنا شوید و باشگاه‌های فعال شهر خودتان را پیدا کنید.</p>
            </div>
        </div>

        <div class="footer-bottom">
            <p>© <?= toPersianDigits(date('Y')) ?> — طراحی‌شده توسط علیرضا ورزن · آرِنا · تمامی حقوق محفوظ است.</p>
        </div>
    </div>
</footer>

<!-- دکمهٔ بازگشت به بالا -->
<button type="button" class="back-to-top" id="backToTop" aria-label="بازگشت به بالای صفحه" hidden>
    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">
        <path d="M12 19V5"/><path d="m5 12 7-7 7 7"/>
    </svg>
</button>

<script src="app.js?v=3.0" defer></script>
</body>
</html>
