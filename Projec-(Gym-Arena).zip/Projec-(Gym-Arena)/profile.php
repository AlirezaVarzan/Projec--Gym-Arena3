<?php
/**
 * ═══════════════════════════════════════════════════════════
 *  حساب من (پروفایل کاربر)
 *  ویرایش اطلاعات پایه، تغییر رمز عبور و مرور آماری فعالیت‌ها.
 * ═══════════════════════════════════════════════════════════
 */
require_once __DIR__ . '/config.php';
requireLogin();

$userId = (int) $_SESSION['user_id'];

/* ═══════════════════════════════════════════════════════════
   بخش ۱ — ویرایش اطلاعات پایه
   ═══════════════════════════════════════════════════════════ */
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['update_profile'])) {
    verifyCsrf();

    $full_name = trim($_POST['full_name'] ?? '');
    $city      = trim($_POST['city'] ?? '');
    $sport_id  = (int) ($_POST['favorite_sport'] ?? 0);

    $errors = [];
    if (mb_strlen($full_name) < 3) {
        $errors[] = 'نام و نام خانوادگی باید حداقل ۳ کاراکتر باشد.';
    }
    if (mb_strlen($city) < 2) {
        $errors[] = 'لطفاً نام شهر را به‌درستی وارد کن.';
    }
    if ($sport_id <= 0) {
        $errors[] = 'لطفاً رشتهٔ ورزشی را انتخاب کن.';
    }

    if ($errors) {
        flash('error', implode(' ', $errors));
    } else {
        $pdo->prepare("UPDATE users SET full_name = ?, city = ?, favorite_sport = ? WHERE id = ?")
            ->execute([$full_name, $city, $sport_id, $userId]);
        flash('success', 'اطلاعات پروفایل با موفقیت به‌روزرسانی شد.');
    }

    redirect('profile.php');
}

/* ═══════════════════════════════════════════════════════════
   بخش ۲ — تغییر رمز عبور
   ═══════════════════════════════════════════════════════════ */
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['change_password'])) {
    verifyCsrf();

    $current  = (string) ($_POST['current_password'] ?? '');
    $new      = (string) ($_POST['new_password'] ?? '');
    $confirm  = (string) ($_POST['new_password_confirm'] ?? '');

    $stmt = $pdo->prepare("SELECT password FROM users WHERE id = ? LIMIT 1");
    $stmt->execute([$userId]);
    $hash = $stmt->fetchColumn();

    if (!$hash || !password_verify($current, $hash)) {
        flash('error', 'رمز عبور فعلی صحیح نیست.');
    } elseif (mb_strlen($new) < 6) {
        flash('error', 'رمز عبور جدید باید حداقل ۶ کاراکتر باشد.');
    } elseif ($new !== $confirm) {
        flash('error', 'رمز عبور جدید و تکرار آن یکسان نیستند.');
    } else {
        $newHash = password_hash($new, PASSWORD_DEFAULT);
        $pdo->prepare("UPDATE users SET password = ? WHERE id = ?")->execute([$newHash, $userId]);
        flash('success', 'رمز عبور با موفقیت تغییر کرد.');
    }

    redirect('profile.php');
}

/* ═══════════════════════════════════════════════════════════
   بخش ۳ — دریافت اطلاعات نمایشی
   ═══════════════════════════════════════════════════════════ */
$stmt = $pdo->prepare("
    SELECT u.*, s.name AS sport_name, s.icon AS sport_icon
    FROM users u
    LEFT JOIN sports s ON u.favorite_sport = s.id
    WHERE u.id = ?
    LIMIT 1
");
$stmt->execute([$userId]);
$user = $stmt->fetch();

if (!$user) {
    session_unset();
    session_destroy();
    redirect('index.php');
}

$sports = $pdo->query("SELECT id, name, icon FROM sports ORDER BY id ASC")->fetchAll();

// آمار فعالیت کاربر
$statsStmt = $pdo->prepare("
    SELECT
        (SELECT COUNT(*) FROM favorites WHERE user_id = ?) AS total_favorites,
        (SELECT COUNT(*) FROM reviews   WHERE user_id = ?) AS total_reviews
");
$statsStmt->execute([$userId, $userId]);
$stats = $statsStmt->fetch();

$success = flash('success');
$error   = flash('error');

$page_title = 'حساب من — آرِنا';

include __DIR__ . '/header.php';
?>

<section class="dashboard-hero">
    <div class="container">
        <div class="dashboard-greeting">حساب کاربری</div>
        <h1 class="dashboard-name"><?= e($user['full_name']) ?> ⚙️</h1>
        <p class="dashboard-lead">اطلاعات حساب خودت را همین‌جا ویرایش کن.</p>
    </div>
</section>

<div class="container">

    <?php if ($success): ?>
        <div class="form-message success" role="status">
            <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" aria-hidden="true"><path d="M20 6 9 17l-5-5"/></svg>
            <span><?= e($success) ?></span>
        </div>
    <?php endif; ?>
    <?php if ($error): ?>
        <div class="form-message error" role="alert">
            <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" aria-hidden="true"><circle cx="12" cy="12" r="10"/><path d="M12 8v4M12 16h.01"/></svg>
            <span><?= e($error) ?></span>
        </div>
    <?php endif; ?>

    <!-- ═══════════ آمار سریع ═══════════ -->
    <div class="profile-stats">
        <div class="profile-stat">
            <span class="ico-emoji" aria-hidden="true">❤</span>
            <div>
                <strong><?= toPersianDigits($stats['total_favorites']) ?></strong>
                <span>باشگاه علاقه‌مندی</span>
            </div>
        </div>
        <div class="profile-stat">
            <span class="ico-emoji" aria-hidden="true">✍️</span>
            <div>
                <strong><?= toPersianDigits($stats['total_reviews']) ?></strong>
                <span>نظر ثبت‌شده</span>
            </div>
        </div>
        <div class="profile-stat">
            <span class="ico-emoji" aria-hidden="true"><?= e($user['sport_icon'] ?? '🏆') ?></span>
            <div>
                <strong><?= e($user['sport_name'] ?? 'انتخاب نشده') ?></strong>
                <span>رشتهٔ محبوب</span>
            </div>
        </div>
        <?php if ($user['is_admin']): ?>
            <div class="profile-stat">
                <span class="ico-emoji" aria-hidden="true">🛡️</span>
                <div>
                    <strong><a href="admin/index.php" style="color:inherit">پنل مدیریت</a></strong>
                    <span>دسترسی ادمین</span>
                </div>
            </div>
        <?php endif; ?>
    </div>

    <div class="profile-grid">

        <!-- ═══════════ فرم ویرایش اطلاعات ═══════════ -->
        <section class="section-compact profile-card">
            <h2 class="subsection-title">اطلاعات پایه</h2>
            <form method="POST">
                <?= csrfField() ?>

                <div class="form-row">
                    <div class="form-group">
                        <label class="form-label" for="p_full_name">نام و نام خانوادگی</label>
                        <input type="text" id="p_full_name" name="full_name" class="form-control"
                               value="<?= e($user['full_name']) ?>" required>
                    </div>
                    <div class="form-group">
                        <label class="form-label">کد ملی</label>
                        <input type="text" class="form-control" value="<?= e(toPersianDigits($user['national_code'])) ?>" disabled>
                    </div>
                </div>

                <div class="form-row">
                    <div class="form-group">
                        <label class="form-label" for="p_sport">رشتهٔ ورزشی مورد علاقه</label>
                        <select id="p_sport" name="favorite_sport" class="form-control" required>
                            <?php foreach ($sports as $sp): ?>
                                <option value="<?= e($sp['id']) ?>" <?= $sp['id'] == $user['favorite_sport'] ? 'selected' : '' ?>>
                                    <?= e($sp['icon']) ?> <?= e($sp['name']) ?>
                                </option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                    <div class="form-group">
                        <label class="form-label" for="p_city">شهر</label>
                        <input type="text" id="p_city" name="city" class="form-control"
                               value="<?= e($user['city']) ?>" required>
                    </div>
                </div>

                <div class="form-row">
                    <div class="form-group">
                        <label class="form-label">نام کاربری</label>
                        <input type="text" class="form-control" value="<?= e($user['username']) ?>" disabled>
                    </div>
                    <div class="form-group">
                        <label class="form-label">عضو از</label>
                        <input type="text" class="form-control" value="<?= e(toPersianDigits(date('Y/m/d', strtotime($user['created_at'])))) ?>" disabled>
                    </div>
                </div>

                <button type="submit" name="update_profile" value="1" class="btn btn-primary">
                    ذخیرهٔ تغییرات
                </button>
            </form>
        </section>

        <!-- ═══════════ فرم تغییر رمز عبور ═══════════ -->
        <section class="section-compact profile-card">
            <h2 class="subsection-title">تغییر رمز عبور</h2>
            <form method="POST">
                <?= csrfField() ?>

                <div class="form-group">
                    <label class="form-label" for="p_current">رمز عبور فعلی</label>
                    <div class="password-wrap">
                        <input type="password" id="p_current" name="current_password" class="form-control"
                               autocomplete="current-password" required>
                        <button type="button" class="password-toggle" data-toggle-password aria-label="نمایش رمز عبور"></button>
                    </div>
                </div>

                <div class="form-row">
                    <div class="form-group">
                        <label class="form-label" for="p_new">رمز عبور جدید</label>
                        <div class="password-wrap">
                            <input type="password" id="p_new" name="new_password" class="form-control"
                                   minlength="6" autocomplete="new-password" required>
                            <button type="button" class="password-toggle" data-toggle-password aria-label="نمایش رمز عبور"></button>
                        </div>
                        <div class="password-meter" data-password-meter hidden>
                            <div class="password-meter-bar"><span></span></div>
                            <small class="password-meter-text"></small>
                        </div>
                    </div>
                    <div class="form-group">
                        <label class="form-label" for="p_new2">تکرار رمز عبور جدید</label>
                        <div class="password-wrap">
                            <input type="password" id="p_new2" name="new_password_confirm" class="form-control"
                                   minlength="6" autocomplete="new-password" required>
                            <button type="button" class="password-toggle" data-toggle-password aria-label="نمایش رمز عبور"></button>
                        </div>
                    </div>
                </div>

                <button type="submit" name="change_password" value="1" class="btn btn-ghost">
                    تغییر رمز عبور
                </button>
            </form>
        </section>
    </div>

</div>

<?php include __DIR__ . '/footer.php'; ?>
